// Assignments & Coursework Engine with User-Specific Submissions
let selectedHomeworkFile = null;

document.addEventListener('DOMContentLoaded', () => {
  checkUserRoleAndPermissions();
  renderAssignments();
  initAssignmentsLiveSync();
});

function checkUserRoleAndPermissions() {
  const container = document.getElementById('teacherPublishAssignBtnContainer');
  const user = appState.currentUser;
  if (container) {
    if (user && user.role === 'teacher') {
      container.style.display = 'flex';
    } else {
      container.style.display = 'none';
    }
  }
}

function initAssignmentsLiveSync() {
  if (window.fbDb && window.fbMethods) {
    window.fbMethods.onSnapshot(window.fbMethods.collection(window.fbDb, "assignments"), (snap) => {
      snap.docChanges().forEach((change) => {
        if (change.type === "added") {
          const a = change.doc.data();
          const exists = appState.assignments.some(item => item.id === change.doc.id || item.title === a.title);
          if (!exists) {
            appState.assignments.unshift({
              id: change.doc.id,
              title: a.title,
              subject: a.subject,
              due: a.due,
              status: a.status || 'Pending',
              attachment: a.attachment || null
            });
            saveState();
            renderAssignments();
          }
        }
      });
    });
  }
}

function renderAssignments() {
  const grid = document.getElementById('fullAssignmentsGrid');
  if (!grid) return;

  const userSubmissions = appState.submissions || {};

  grid.innerHTML = appState.assignments.map(a => {
    // Check if THIS logged in user submitted this assignment
    const submission = userSubmissions[a.id];
    const isSubmitted = !!submission;
    const currentStatus = isSubmitted ? 'Completed' : (a.status || 'Pending');
    const badgeStyle = getStatusStyle(currentStatus);

    return `
      <div class="bento-card p-5 flex flex-col justify-between hover:border-slate-300 transition">
        <div>
          <div class="flex items-center justify-between mb-2">
            <span class="text-[10px] font-bold text-slate-400 uppercase">${a.subject}</span>
            <span class="px-2 py-0.5 rounded-full text-[10px] font-extrabold ${badgeStyle}">${currentStatus}</span>
          </div>
          <h4 class="text-sm font-bold text-slate-900">${a.title}</h4>
          <p class="text-xs text-slate-500 mt-1">⏳ ${a.due}</p>
          
          ${isSubmitted ? `
            <div class="mt-2.5 p-2 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-between text-[11px]">
              <span class="text-emerald-800 font-bold truncate">✓ Submitted: ${submission.fileName}</span>
              <span class="text-[10px] text-emerald-600 font-semibold">${submission.submittedAt || 'Done'}</span>
            </div>
          ` : ''}
        </div>

        <div class="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
          <button onclick="openSubmitHomeworkModal('${a.id}', '${a.title}')" class="flex-1 py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-sm transition text-center">
            ${isSubmitted ? 'Re-upload Solution' : '📤 Upload Solution'}
          </button>
          ${appState.currentUser && appState.currentUser.role === 'teacher' ? `
          <button onclick="deleteAssignmentItem('${a.id}')" title="Delete" class="p-2 text-slate-400 hover:text-rose-600 rounded-xl transition">
            🗑️
          </button>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

function openAddTaskModal() {
  document.getElementById('addTaskModal').classList.remove('hidden');
}

function closeAddTaskModal() {
  document.getElementById('addTaskModal').classList.add('hidden');
}

async function handleAddTask(e) {
  e.preventDefault();
  const title = document.getElementById('newTaskTitle').value.trim();
  const subject = document.getElementById('newTaskSubject').value.trim();
  const due = document.getElementById('newTaskDue').value.trim();
  const status = document.getElementById('newTaskPriority').value;
  const fileInput = document.getElementById('assignmentAttachmentFile');

  let assignId = 'asgn_' + Date.now().toString();
  let fileName = fileInput.files[0] ? fileInput.files[0].name : null;

  if (window.fbDb && window.fbMethods) {
    try {
      const docRef = await window.fbMethods.addDoc(window.fbMethods.collection(window.fbDb, "assignments"), {
        title,
        subject,
        due,
        status,
        attachment: fileName,
        author: appState.currentUser ? appState.currentUser.name : 'Faculty',
        createdAt: window.fbMethods.serverTimestamp()
      });
      assignId = docRef.id;
    } catch(e) {}
  }

  appState.assignments.unshift({
    id: assignId,
    title,
    subject,
    due,
    status,
    attachment: fileName
  });
  saveState();
  closeAddTaskModal();
  renderAssignments();
  showToast('✅ Assignment published and synced!');
}

function deleteAssignmentItem(id) {
  appState.assignments = appState.assignments.filter(a => a.id !== id);
  saveState();
  renderAssignments();
  showToast('Assignment removed');
}

// Student Homework Upload
function openSubmitHomeworkModal(id, title) {
  selectedHomeworkFile = null;
  document.getElementById('submissionAssignmentId').value = id;
  document.getElementById('submissionAssignmentName').value = title;
  document.getElementById('submissionModalTitle').innerText = `Submit: ${title}`;
  document.getElementById('hwPlaceholder').classList.remove('hidden');
  document.getElementById('hwSelectedBadge').classList.add('hidden');
  document.getElementById('homeworkFileInput').value = '';
  document.getElementById('submitHomeworkModal').classList.remove('hidden');
}

function closeSubmitHomeworkModal() {
  document.getElementById('submitHomeworkModal').classList.add('hidden');
}

function handleHomeworkFilePick(e) {
  const file = e.target.files[0];
  if (!file) return;

  selectedHomeworkFile = file;
  const kb = Math.round(file.size / 1024);
  const sizeFormatted = kb > 1024 ? (kb / 1024).toFixed(1) + " MB" : kb + " KB";

  document.getElementById('hwPlaceholder').classList.add('hidden');
  document.getElementById('hwSelectedBadge').classList.remove('hidden');
  document.getElementById('hwFileName').innerText = "📄 " + file.name;
  document.getElementById('hwFileSize').innerText = `${sizeFormatted} • Selected`;
}

async function handleHomeworkFileSubmit(e) {
  e.preventDefault();
  const assignId = document.getElementById('submissionAssignmentId').value;
  const title = document.getElementById('submissionAssignmentName').value;
  const note = document.getElementById('hwStudentNote').value;
  const fileName = selectedHomeworkFile ? selectedHomeworkFile.name : 'Solution_Document.pdf';

  showToast(`Uploading ${fileName}...`);

  let cloudFileUrl = null;
  if (window.fbStorage && window.fbMethods && selectedHomeworkFile) {
    try {
      const storageRef = window.fbMethods.ref(window.fbStorage, `submissions/${Date.now()}_${selectedHomeworkFile.name}`);
      const uploadSnapshot = await window.fbMethods.uploadBytes(storageRef, selectedHomeworkFile);
      cloudFileUrl = await window.fbMethods.getDownloadURL(uploadSnapshot.ref);
    } catch(err) {
      console.warn("Storage upload notice:", err);
    }
  }

  // Strictly save submission inside THIS user's isolated submissions map!
  if (!appState.submissions) appState.submissions = {};
  appState.submissions[assignId] = {
    fileName: fileName,
    status: 'Completed',
    note: note,
    fileUrl: cloudFileUrl,
    submittedAt: 'Just now'
  };
  saveState();

  // Sync submission to Firestore with student credentials
  if (window.fbDb && window.fbMethods) {
    try {
      await window.fbMethods.addDoc(window.fbMethods.collection(window.fbDb, "submissions"), {
        assignmentId: assignId,
        assignmentTitle: title,
        fileName: fileName,
        fileUrl: cloudFileUrl,
        studentName: appState.profile ? appState.profile.name : (appState.currentUser ? appState.currentUser.name : 'Student'),
        studentRoll: appState.profile ? appState.profile.roll : (appState.currentUser ? appState.currentUser.roll : 'Roll No'),
        studentEmail: appState.currentUser ? appState.currentUser.email : 'student@campus.edu',
        note: note,
        submittedAt: window.fbMethods.serverTimestamp()
      });
    } catch(e) {}
  }

  closeSubmitHomeworkModal();
  renderAssignments();
  showToast(`✅ Homework solution uploaded successfully for ${title}!`);
}

function getStatusStyle(st) {
  if (st === 'Urgent') return 'bg-rose-100 text-rose-700';
  if (st === 'Pending') return 'bg-amber-100 text-amber-700';
  return 'bg-emerald-100 text-emerald-700';
}
