// Firebase SDK Integration (Modular CDN v12)
// Connected to your NEW Firebase Project: smart-campus-8ffb9

import { initializeApp } from "https://www.gstatic.com/firebasejs/12.19.0/firebase-app.js";
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged 
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-auth.js";
import { 
  getFirestore, 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc,
  collection, 
  getDocs, 
  addDoc, 
  deleteDoc,
  onSnapshot, 
  query, 
  orderBy, 
  serverTimestamp 
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-firestore.js";
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject
} from "https://www.gstatic.com/firebasejs/12.19.0/firebase-storage.js";

const firebaseConfig = {
  apiKey: "AIzaSyCfgBMwx0PvaTupl7HVH5avg484leNS8CA",
  authDomain: "smart-campus-8ffb9.firebaseapp.com",
  projectId: "smart-campus-8ffb9",
  storageBucket: "smart-campus-8ffb9.firebasestorage.app",
  messagingSenderId: "809810086460",
  appId: "1:809810086460:web:0dcdb404392c46e4935139",
  measurementId: "G-9JCT6J9FFT"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

// Global Firebase helper methods exported for application modules
window.fbAuth = auth;
window.fbDb = db;
window.fbStorage = storage;
window.fbMethods = {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  getDocs,
  addDoc,
  deleteDoc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject
};

console.log("🔥 Smart Campus Live Firebase & Cloud Storage Connected: smart-campus-8ffb9");
