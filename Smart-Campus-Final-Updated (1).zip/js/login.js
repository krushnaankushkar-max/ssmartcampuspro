function clearAllAuthInputs() {
  const fields = ['loginEmail', 'loginPassword', 'regName', 'regRoll', 'regEmail', 'regPassword'];
  fields.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
}

// Strict Multi-User Authentication Engine (English-Only Alerts & No Demo Bypass)
let selectedRole = 'student';
let currentAuthMode = 'register'; // 'register' | 'signin'

document.addEventListener('DOMContentLoaded', () => {
  const urlParams = new URLSearchParams(window.location.search);
  const modeParam = urlParams.get('mode');
  const path = window.location.pathname.toLowerCase();

  // Clear all form inputs on page load
  clearAllAuthInputs();

  // If URL has ?mode=signin or path is login.html, activate Sign In tab, otherwise Register
  if (modeParam === 'signin' || path.endsWith('login.html')) {
    switchAuthTab('signin');
  } else {
    switchAuthTab('register');
  }

  // Defeat aggressive browser password autofill after render
  setTimeout(() => {
    clearAllAuthInputs();
  }, 100);
});

function switchAuthTab(mode) {
  currentAuthMode = mode;
  clearAllAuthInputs();
  const tabSignIn = document.getElementById('tabModeSignIn');
  const tabReg = document.getElementById('tabModeRegister');
  const formReg = document.getElementById('formRegister');
  const formSign = document.getElementById('formSignIn');
  const title = document.getElementById('authMainTitle');
  const sub = document.getElementById('authMainSub');

  if (mode === 'signin') {
    if (tabSignIn) {
      tabSignIn.className = 'flex-1 py-2 text-xs sm:text-sm font-bold rounded-xl bg-white text-indigo-700 shadow-sm border border-slate-200/60 transition duration-150';
    }
    if (tabReg) {
      tabReg.className = 'flex-1 py-2 text-xs sm:text-sm font-bold rounded-xl text-slate-500 hover:text-slate-900 transition duration-150';
    }
    if (formSign) {
      formSign.classList.remove('hidden');
      const emailField = document.getElementById('loginEmail');
      const passField = document.getElementById('loginPassword');
      if (emailField) emailField.value = '';
      if (passField) passField.value = '';
    }
    if (formReg) formReg.classList.add('hidden');
    if (title) title.innerText = 'Welcome Back';
    if (sub) sub.innerText = 'Enter your registered credentials to sign in.';
  } else {
    if (tabReg) {
      tabReg.className = 'flex-1 py-2 text-xs sm:text-sm font-bold rounded-xl bg-white text-indigo-700 shadow-sm border border-slate-200/60 transition duration-150';
    }
    if (tabSignIn) {
      tabSignIn.className = 'flex-1 py-2 text-xs sm:text-sm font-bold rounded-xl text-slate-500 hover:text-slate-900 transition duration-150';
    }
    if (formReg) formReg.classList.remove('hidden');
    if (formSign) formSign.classList.add('hidden');
    if (title) title.innerText = 'Create Account';
    if (sub) sub.innerText = 'Fill in your details to create a new campus account.';
  }
}

function selectRole(role) {
  selectedRole = role;
  const btnStud = document.getElementById('roleBtnStudent');
  const btnTeach = document.getElementById('roleBtnTeacher');
  const rollLabel = document.getElementById('regRollLabel');
  const rollInput = document.getElementById('regRoll');
  const loginEmailInput = document.getElementById('loginEmail');

  if (role === 'student') {
    if (btnStud) {
      btnStud.className = 'py-2.5 px-3 rounded-xl border-2 border-indigo-600 bg-white text-indigo-700 font-bold text-xs flex items-center justify-center gap-2 transition shadow-sm';
    }
    if (btnTeach) {
      btnTeach.className = 'py-2.5 px-3 rounded-xl border-2 border-transparent bg-transparent text-slate-600 font-semibold text-xs flex items-center justify-center gap-2 transition hover:text-slate-900';
    }
    if (rollLabel) rollLabel.innerText = 'Roll No. / Student ID';
    if (rollInput) rollInput.placeholder = 'Enter Roll No. or Student ID';
    if (loginEmailInput) loginEmailInput.placeholder = 'name@campus.edu or Roll No.';
  } else {
    if (btnTeach) {
      btnTeach.className = 'py-2.5 px-3 rounded-xl border-2 border-indigo-600 bg-white text-indigo-700 font-bold text-xs flex items-center justify-center gap-2 transition shadow-sm';
    }
    if (btnStud) {
      btnStud.className = 'py-2.5 px-3 rounded-xl border-2 border-transparent bg-transparent text-slate-600 font-semibold text-xs flex items-center justify-center gap-2 transition hover:text-slate-900';
    }
    if (rollLabel) rollLabel.innerText = 'Faculty ID / Employee Code';
    if (rollInput) rollInput.placeholder = 'Enter Faculty ID or Code';
    if (loginEmailInput) loginEmailInput.placeholder = 'faculty@campus.edu or Employee ID';
  }
}

// Find user bucket by email OR roll number
function findLocalUser(identifier) {
  if (!identifier) return null;
  const cleanId = identifier.trim().toLowerCase();

  const directKey = 'smart_campus_user_' + encodeURIComponent(cleanId);
  const directItem = localStorage.getItem(directKey);
  if (directItem) {
    try {
      return { key: directKey, data: JSON.parse(directItem) };
    } catch(e) {}
  }

  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith('smart_campus_user_')) {
      try {
        const item = JSON.parse(localStorage.getItem(key));
        if (item && item.profile) {
          const profileEmail = (item.profile.email || '').toLowerCase().trim();
          const profileRoll = (item.profile.roll || '').toLowerCase().trim();
          if (profileEmail === cleanId || profileRoll === cleanId) {
            return { key, data: item };
          }
        }
      } catch(e) {}
    }
  }

  return null;
}

// ----------------- CREATE ACCOUNT -----------------
async function handleUnifiedRegister(e) {
  if (e && e.preventDefault) e.preventDefault();

  const nameEl = document.getElementById('regName');
  const rollEl = document.getElementById('regRoll');
  const emailEl = document.getElementById('regEmail');
  const passEl = document.getElementById('regPassword');
  const submitBtn = e && e.target ? e.target.querySelector('button[type="submit"]') : null;

  const name = nameEl ? nameEl.value.trim() : '';
  const roll = rollEl ? rollEl.value.trim() : '';
  const email = emailEl ? emailEl.value.trim() : '';
  const password = passEl ? passEl.value : '';

  if (!name || !roll || !email || !password) {
    showToast("⚠️ Please enter all details (Name, Roll No, Email, Password).");
    return false;
  }

  if (password.length < 6) {
    showToast("⚠️ Password must be at least 6 characters long.");
    return false;
  }

  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span>Creating Account...</span><span class="ml-2 animate-spin">⏳</span>';
  }

  showToast("Creating your account...");

  let firebaseUid = null;

  // Firebase Auth Creation
  if (window.fbAuth && window.fbMethods) {
    try {
      const authPromise = window.fbMethods.createUserWithEmailAndPassword(window.fbAuth, email, password);
      const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error("auth_timeout")), 3000));
      
      const userCred = await Promise.race([authPromise, timeoutPromise]);
      firebaseUid = userCred.user.uid;

      if (window.fbDb) {
        window.fbMethods.setDoc(window.fbMethods.doc(window.fbDb, "users", firebaseUid), {
          uid: firebaseUid,
          name: name,
          roll: roll,
          email: email,
          role: selectedRole,
          createdAt: window.fbMethods.serverTimestamp()
        }, { merge: true }).catch(() => {});
      }
    } catch (fbErr) {
      if (fbErr.code === 'auth/email-already-in-use') {
        showToast("⚠️ This email is already registered. Please sign in.");
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = '<span>Register & Open Portal</span><span>→</span>';
        }
        switchAuthTab('signin');
        return false;
      }
      console.warn("Firebase Auth Notice:", fbErr);
    }
  }

  // Create Isolated Local Storage Partition
  const finalUid = firebaseUid || ('user_' + Date.now());
  const session = { uid: finalUid, name, roll, role: selectedRole, email };
  localStorage.setItem('smart_campus_current_session', JSON.stringify(session));

  const userKey = 'smart_campus_user_' + encodeURIComponent(email.toLowerCase().trim());
  const freshStudent = {
    profile: { name, roll, email, role: selectedRole, department: 'Computer Engineering' },
    password: password,
    attendance: {
      overallPercentage: 0,
      attended: 0,
      missed: 0,
      safeSubjects: 0,
      totalSubjects: 6,
      subjects: [
        { id: 1, name: 'Data Structures & Algorithms', attended: 0, total: 0, percent: 0 },
        { id: 2, name: 'Mathematics III', attended: 0, total: 0, percent: 0 },
        { id: 3, name: 'Operating Systems', attended: 0, total: 0, percent: 0 },
        { id: 4, name: 'Human-Computer Interaction', attended: 0, total: 0, percent: 0 },
        { id: 5, name: 'Database Management Systems', attended: 0, total: 0, percent: 0 },
        { id: 6, name: 'Computer Networks', attended: 0, total: 0, percent: 0 }
      ]
    },
    submissions: {},
    documents: [],
    notifications: [{ id: Date.now(), text: `Welcome to Smart Campus, ${name}!`, unread: true, time: 'Just now' }]
  };
  localStorage.setItem(userKey, JSON.stringify(freshStudent));

  // Add this student to teacher roster
  let globalData = JSON.parse(localStorage.getItem('smart_campus_global_state') || '{}');
  if (!globalData.studentsList) globalData.studentsList = [];
  const exists = globalData.studentsList.some(s => s.roll.toLowerCase() === roll.toLowerCase());
  if (!exists) {
    globalData.studentsList.push({ roll: roll, name: name });
    localStorage.setItem('smart_campus_global_state', JSON.stringify(globalData));
  }

  if (typeof loadAppState === 'function') {
    appState = loadAppState();
  }

  showToast(`✅ Account created successfully! Welcome, ${name}!`);
  setTimeout(() => {
    window.location.href = (selectedRole === 'teacher') ? 'teacher.html' : 'dashboard.html';
  }, 400);

  return false;
}

// ----------------- STRICT SIGN IN (ONLY REGISTERED USERS) -----------------
async function handleUnifiedSignIn(e) {
  if (e && e.preventDefault) e.preventDefault();
  
  const emailEl = document.getElementById('loginEmail');
  const passEl = document.getElementById('loginPassword');
  
  const identifier = emailEl ? emailEl.value.trim() : '';
  const password = passEl ? passEl.value : '';
  const submitBtn = e && e.target ? e.target.querySelector('button[type="submit"]') : null;

  if (!identifier || !password) {
    showToast("⚠️ Please enter both Email / Roll No. and Password.");
    return false;
  }

  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span>Verifying...</span><span class="ml-2 animate-spin">⏳</span>';
  }

  showToast("Verifying credentials...");

  // Match in local database (supports Roll No. or Email)
  const localMatch = findLocalUser(identifier);
  const parsedData = localMatch ? localMatch.data : null;

  const resolvedEmail = (parsedData && parsedData.profile && parsedData.profile.email) 
                        ? parsedData.profile.email 
                        : (identifier.includes('@') ? identifier : `${identifier.toLowerCase()}@campus.edu`);

  let firebaseLoginSuccess = false;
  let remoteUserData = null;
  let firebaseUid = null;

  // 1. Firebase Authentication Verification
  if (window.fbAuth && window.fbMethods && resolvedEmail.includes('@')) {
    try {
      const authPromise = window.fbMethods.signInWithEmailAndPassword(window.fbAuth, resolvedEmail, password);
      const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error("auth_timeout")), 2500));
      
      const userCred = await Promise.race([authPromise, timeoutPromise]);
      firebaseUid = userCred.user.uid;
      firebaseLoginSuccess = true;

      if (window.fbDb) {
        try {
          const userDoc = await window.fbMethods.getDoc(window.fbMethods.doc(window.fbDb, "users", firebaseUid));
          if (userDoc.exists()) remoteUserData = userDoc.data();
        } catch(docErr) {}
      }
    } catch (fbErr) {
      console.warn("Firebase sign-in notice:", fbErr.code || fbErr.message);
      if (fbErr.code === 'auth/wrong-password' || fbErr.code === 'auth/invalid-credential') {
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = '<span>Sign In to Portal</span><span>→</span>';
        }
        showToast("❌ Incorrect password. Please try again.");
        return false;
      }
    }
  }

  // 2. Strict Account Check (If account doesn't exist, STRICTLY REJECT)
  if (!firebaseLoginSuccess) {
    if (!parsedData) {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<span>Sign In to Portal</span><span>→</span>';
      }
      showToast("❌ User not found. Please create an account first.");
      return false;
    }

    // Verify Password against registered account
    if (parsedData.password && parsedData.password !== password) {
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<span>Sign In to Portal</span><span>→</span>';
      }
      showToast("❌ Incorrect password. Please try again.");
      return false;
    }
  }

  // Login Successful
  const finalRole = remoteUserData?.role || (parsedData?.profile?.role) || selectedRole;
  const finalName = remoteUserData?.name || (parsedData?.profile?.name) || identifier.split('@')[0];
  const finalRoll = remoteUserData?.roll || (parsedData?.profile?.roll) || '';
  const finalEmail = remoteUserData?.email || (parsedData?.profile?.email) || resolvedEmail;

  const session = {
    uid: firebaseUid || ('user_' + Date.now()),
    name: finalName,
    roll: finalRoll,
    role: finalRole,
    email: finalEmail
  };

  localStorage.setItem('smart_campus_current_session', JSON.stringify(session));

  if (typeof loadAppState === 'function') {
    appState = loadAppState();
  }

  showToast(`✅ Welcome, ${finalName}!`);
  setTimeout(() => {
    window.location.href = (finalRole === 'teacher') ? 'teacher.html' : 'dashboard.html';
  }, 400);

  return false;
}
