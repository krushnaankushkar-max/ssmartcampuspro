// Dynamic Timetable Engine (Strict Faculty-Only Permissions & Live Attendance Sync)

const DEFAULT_TIMETABLE = [
  {
    time: "09:00 - 10:30",
    Monday: "Data Structures (Lab 4B)",
    Tuesday: "Maths III (Room 102)",
    Wednesday: "Data Structures (Lab 4B)",
    Thursday: "Operating Systems (Lab 1)",
    Friday: "HCI Seminar (Hall 2)"
  },
  {
    time: "11:00 - 12:30",
    Monday: "Operating Systems (Lab 1)",
    Tuesday: "Database Systems (Lab 3)",
    Wednesday: "Maths III (Room 102)",
    Thursday: "Computer Networks (Room 201)",
    Friday: "Data Structures (Lab 4B)"
  },
  {
    time: "01:30 - 03:00",
    Monday: "Physics Lab",
    Tuesday: "HCI (Room 405)",
    Wednesday: "Software Engg (Room 304)",
    Thursday: "Library / Self Study",
    Friday: "Project Prep (Lab 4B)"
  },
  {
    time: "03:15 - 04:45",
    Monday: "Mentorship Session",
    Tuesday: "Remedial Coding",
    Wednesday: "Elective Lab",
    Thursday: "Sports / Extra Curricular",
    Friday: "Faculty Review"
  }
];

if (!appState.timetable) {
  appState.timetable = DEFAULT_TIMETABLE;
  saveState();
}

document.addEventListener('DOMContentLoaded', () => {
  checkTimetableTeacherPermissions();
  renderTimetable();
  initTimetableLiveSync();
});

function checkTimetableTeacherPermissions() {
  const container = document.getElementById('teacherEditTimetableBtnContainer');
  const user = appState.currentUser;
  
  // Strictly allow modifying timetable only for Faculty/Teacher
  if (container) {
    if (user && user.role === 'teacher') {
      container.style.display = 'flex';
    } else {
      container.style.display = 'none';
    }
  }
}

function initTimetableLiveSync() {
  if (window.fbDb && window.fbMethods) {
    const ttDoc = window.fbMethods.doc(window.fbDb, "system", "timetable");
    window.fbMethods.onSnapshot(ttDoc, (snap) => {
      if (snap.exists()) {
        const cloudData = snap.data();
        if (cloudData.slots && Array.isArray(cloudData.slots)) {
          appState.timetable = cloudData.slots;
          saveState();
          renderTimetable();
        }
      }
    });
  }
}

function renderTimetable() {
  const tbody = document.getElementById('timetableBody');
  if (!tbody) return;

  tbody.innerHTML = appState.timetable.map((row, idx) => `
    <tr class="hover:bg-slate-50/60 transition">
      <td class="p-3 font-mono font-bold text-slate-400 bg-slate-50/50">${row.time}</td>
      <td class="p-3 ${row.Monday && row.Monday.includes('Data') ? 'bg-blue-50/60 font-semibold text-blue-900' : ''}">${row.Monday || '-'}</td>
      <td class="p-3">${row.Tuesday || '-'}</td>
      <td class="p-3 ${row.Wednesday && row.Wednesday.includes('Data') ? 'bg-blue-50/60 font-semibold text-blue-900' : ''}">${row.Wednesday || '-'}</td>
      <td class="p-3">${row.Thursday || '-'}</td>
      <td class="p-3">${row.Friday || '-'}</td>
    </tr>
  `).join('');
}

function openEditTimetableModal() {
  const user = appState.currentUser;
  if (!user || user.role !== 'teacher') {
    showToast('⛔ Only Faculty members can modify timetable records.');
    return;
  }
  document.getElementById('timetableModal').classList.remove('hidden');
}

function closeEditTimetableModal() {
  document.getElementById('timetableModal').classList.add('hidden');
}

async function handleTimetableUpdate(e) {
  e.preventDefault();

  const user = appState.currentUser;
  if (!user || user.role !== 'teacher') {
    showToast('⛔ Permission Denied: Only teachers can modify the timetable.');
    closeEditTimetableModal();
    return;
  }

  const day = document.getElementById('ttDay').value;
  const slotIdx = parseInt(document.getElementById('ttSlotIndex').value);
  const subject = document.getElementById('ttSubject').value.trim();
  const location = document.getElementById('ttLocation').value.trim();

  if (!subject) return;

  const formattedValue = `${subject} (${location})`;

  if (appState.timetable[slotIdx]) {
    appState.timetable[slotIdx][day] = formattedValue;

    // --- AUTO-SYNC WITH ATTENDANCE ---
    // If this new subject is not yet in attendance list, add it automatically!
    syncSubjectToAttendance(subject);

    saveState();
    renderTimetable();
    closeEditTimetableModal();
    showToast(`✅ Timetable updated & '${subject}' added to Attendance!`);

    // Sync to Cloud Firestore
    if (window.fbDb && window.fbMethods) {
      try {
        const ttDoc = window.fbMethods.doc(window.fbDb, "system", "timetable");
        await window.fbMethods.setDoc(ttDoc, {
          slots: appState.timetable,
          lastUpdatedBy: user.name,
          updatedAt: window.fbMethods.serverTimestamp()
        }, { merge: true });

        // Also sync updated attendance subjects list to Firestore
        const attDoc = window.fbMethods.doc(window.fbDb, "system", "attendance_subjects");
        await window.fbMethods.setDoc(attDoc, {
          subjects: appState.attendance.subjects,
          updatedAt: window.fbMethods.serverTimestamp()
        }, { merge: true });
      } catch(err) {
        console.warn("Firestore timetable sync notice:", err);
      }
    }
  }
}

function syncSubjectToAttendance(rawSubjectName) {
  if (!appState.attendance) return;
  if (!appState.attendance.subjects) appState.attendance.subjects = [];

  // Clean subject name e.g. "Data Structures"
  const cleanName = rawSubjectName.replace(/\s*\(.*\)/g, '').trim();

  // Check if already exists (case-insensitive)
  const exists = appState.attendance.subjects.some(
    s => s.name.toLowerCase() === cleanName.toLowerCase()
  );

  if (!exists && cleanName.length > 1) {
    const newSubjectId = appState.attendance.subjects.length > 0 
      ? Math.max(...appState.attendance.subjects.map(s => s.id)) + 1 
      : 1;

    // Add subject with initial safe attendance baseline
    appState.attendance.subjects.push({
      id: newSubjectId,
      name: cleanName,
      attended: 10,
      total: 12,
      percent: 83
    });

    appState.attendance.totalSubjects = appState.attendance.subjects.length;
  }
}
