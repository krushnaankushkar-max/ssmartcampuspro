// User Profile Sync & Presentation Manager
document.addEventListener('DOMContentLoaded', () => {
  if (typeof loadAppState === 'function') {
    appState = loadAppState();
  }
  populateUserProfileData();
});

function populateUserProfileData() {
  const current = appState.currentUser || JSON.parse(localStorage.getItem('smart_campus_current_session') || 'null') || {};
  const prof = appState.profile || {};

  const name = prof.name || current.name || 'Student';
  const roll = prof.roll || current.roll || 'COMP-2026-018';
  const email = prof.email || current.email || 'student@campus.edu';
  const role = current.role || 'student';
  const dept = prof.department || 'Computer Engineering';
  const phone = prof.phone || '+91 98765 00000';

  // Center display card
  const bigName = document.getElementById('profileNameBig');
  const bigRoll = document.getElementById('profileRollBig');
  if (bigName) bigName.innerText = name;
  if (bigRoll) bigRoll.innerText = `${roll} • ${role.charAt(0).toUpperCase() + role.slice(1)}`;

  // Form input fields
  const inputName = document.getElementById('profInputName');
  const inputRoll = document.getElementById('profInputRoll');
  const inputEmail = document.getElementById('profInputEmail');
  const inputPhone = document.getElementById('profInputPhone');
  const inputDept = document.getElementById('profInputDept');

  if (inputName) inputName.value = name;
  if (inputRoll) inputRoll.value = roll;
  if (inputEmail) inputEmail.value = email;
  if (inputPhone) inputPhone.value = phone;
  if (inputDept) inputDept.value = dept;
}
