// Attendance Calculation, Dynamic Log-Driven Health & Teacher Roll-Call Engine

document.addEventListener('DOMContentLoaded', () => {
  if (typeof loadAppState === 'function') {
    appState = loadAppState();
  }
  checkAttendanceTeacherPermissions();
  initAttendanceLiveSync();
  populateAttendanceFilters();
  syncAttendanceWithLogs();
  renderAttendanceList();
  renderAttendanceHistory();
});

function checkAttendanceTeacherPermissions() {
  const container = document.getElementById('teacherMarkAttendanceBtnContainer');
  const user = appState.currentUser;
  if (container) {
    if (user && user.role === 'teacher') {
      container.style.display = 'inline-block';
    } else {
      container.style.display = 'none';
    }
  }
}

function initAttendanceLiveSync() {
  if (window.fbDb && window.fbMethods) {
    const attDoc = window.fbMethods.doc(window.fbDb, "system", "attendance_subjects");
    window.fbMethods.onSnapshot(attDoc, (snap) => {
      if (snap.exists() && snap.data().subjects) {
        appState.attendance.subjects = snap.data().subjects;
        saveState();
        populateAttendanceFilters();
        syncAttendanceWithLogs();
        renderAttendanceList();
      }
    });

    const qLogs = window.fbMethods.query(
      window.fbMethods.collection(window.fbDb, "attendance_history"),
      window.fbMethods.orderBy("timestamp", "desc")
    );
    window.fbMethods.onSnapshot(qLogs, (snap) => {
      snap.docChanges().forEach((change) => {
        if (change.type === "added") {
          const logData = change.doc.data();
          const exists = appState.attendanceHistory && appState.attendanceHistory.some(
            h => (h.id === change.doc.id) || (h.date === logData.date && h.subject === logData.subject && h.roll === logData.roll)
          );
          if (!exists) {
            if (!appState.attendanceHistory) appState.attendanceHistory = [];
            appState.attendanceHistory.unshift({
              id: change.doc.id,
              date: logData.date,
              subject: logData.subject,
              roll: logData.roll,
              studentName: logData.studentName,
              status: logData.status
            });
            saveState();
            syncAttendanceWithLogs();
            renderAttendanceHistory();
            renderAttendanceList();
          }
        }
      });
    });
  }
}

function populateAttendanceFilters() {
  const subjectFilter = document.getElementById('attSubjectFilter');
  const modalSubjectSelect = document.getElementById('teacherModalSubjectSelect');
  const subjects = appState.attendance ? appState.attendance.subjects : [];

  if (subjectFilter) {
    const currentVal = subjectFilter.value;
    subjectFilter.innerHTML = '<option value="all">All Subjects</option>' + subjects.map(s => `
      <option value="${s.name}">${s.name}</option>
    `).join('');
    subjectFilter.value = currentVal || 'all';
  }

  if (modalSubjectSelect) {
    modalSubjectSelect.innerHTML = subjects.map(s => `
      <option value="${s.name}">${s.name}</option>
    `).join('');
  }

  const dateInput = document.getElementById('teacherModalAttendanceDate');
  if (dateInput && !dateInput.value) {
    dateInput.value = new Date().toISOString().split('T')[0];
  }
}

// Dynamically compute subject attended & total directly from teacher's marked history logs for THIS student!
function syncAttendanceWithLogs() {
  if (!appState.attendance || !appState.attendance.subjects) return;

  const current = appState.currentUser || JSON.parse(localStorage.getItem('smart_campus_current_session') || '{}');
  const myRoll = current.roll || (appState.profile ? appState.profile.roll : null);
  const logs = appState.attendanceHistory || [];

  // Filter ONLY logs for this student's roll number!
  const studentLogs = myRoll ? logs.filter(l => l.roll === myRoll) : [];

  const logsBySubject = {};
  studentLogs.forEach(l => {
    if (!logsBySubject[l.subject]) {
      logsBySubject[l.subject] = { attended: 0, total: 0 };
    }
    logsBySubject[l.subject].total += 1;
    if (l.status === 'Present') {
      logsBySubject[l.subject].attended += 1;
    }
  });

  let totalAttended = 0;
  let totalClasses = 0;
  let safeCount = 0;

  appState.attendance.subjects.forEach(sub => {
    const subjectStats = logsBySubject[sub.name];
    if (subjectStats && subjectStats.total > 0) {
      sub.attended = subjectStats.attended;
      sub.total = subjectStats.total;
    } else {
      sub.attended = 0;
      sub.total = 0;
    }
    sub.percent = sub.total > 0 ? Math.round((sub.attended / sub.total) * 100) : 0;
    totalAttended += sub.attended;
    totalClasses += sub.total;
    if (sub.percent >= 75) safeCount++;
  });

  appState.attendance.attended = totalAttended;
  appState.attendance.missed = Math.max(0, totalClasses - totalAttended);
  appState.attendance.overallPercentage = totalClasses > 0 ? Math.round((totalAttended / totalClasses) * 100) : 0;
  appState.attendance.safeSubjects = safeCount;
  saveState();
}

function renderAttendanceList() {
  const container = document.getElementById('subjectAttendanceList');
  const overallEl = document.getElementById('attOverallPercent');
  const totalAttEl = document.getElementById('attTotalAttended');
  const safeCountEl = document.getElementById('attSafeCountDetailed');

  if (overallEl) overallEl.innerText = `${appState.attendance.overallPercentage}%`;
  if (totalAttEl) totalAttEl.innerText = appState.attendance.attended;
  if (safeCountEl) safeCountEl.innerText = `${appState.attendance.safeSubjects} / ${appState.attendance.totalSubjects}`;

  if (!container) return;

  const isTeacher = appState.currentUser && appState.currentUser.role === 'teacher';

  container.innerHTML = appState.attendance.subjects.map(s => {
    const isSafe = s.percent >= 75;
    return `
      <div class="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-slate-300 transition">
        <div>
          <div class="flex items-center gap-2">
            <h4 class="text-xs font-bold text-slate-800">${s.name}</h4>
            <span class="px-2 py-0.5 rounded-full text-[10px] font-extrabold ${isSafe ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-700'}">
              ${isSafe ? '✓ Safe' : '⚠ Shortfall'}
            </span>
          </div>
          <p class="text-[11px] text-slate-400 mt-1">Attended: <strong>${s.attended}</strong> / ${s.total} Lectures</p>
        </div>

        <div class="flex items-center gap-4">
          <div class="text-right">
            <div class="text-sm font-black ${isSafe ? 'text-emerald-600' : 'text-rose-600'}">${s.percent}%</div>
            <div class="text-[10px] text-slate-400">Min 75% req.</div>
          </div>
          ${isTeacher ? `
          <div class="flex items-center gap-1">
            <button onclick="adjustSubjectAttendance(${s.id}, 1)" title="Add 1 lecture attended" class="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center transition">+</button>
            <button onclick="adjustSubjectAttendance(${s.id}, -1)" title="Deduct 1 lecture attended" class="w-7 h-7 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center transition">-</button>
          </div>
          ` : ''}
        </div>
      </div>
    `;
  }).join('');
}

// ----------------- DATE-WISE ATTENDANCE HISTORY -----------------
function filterAttendanceHistory() {
  renderAttendanceHistory();
}

function renderAttendanceHistory() {
  const tbody = document.getElementById('attendanceHistoryTableBody');
  if (!tbody) return;

  const dateFilter = document.getElementById('attDateFilter') ? document.getElementById('attDateFilter').value : '';
  const subjectFilter = document.getElementById('attSubjectFilter') ? document.getElementById('attSubjectFilter').value : 'all';
  const statusFilter = document.getElementById('attStatusFilter') ? document.getElementById('attStatusFilter').value : 'all';

  let logs = appState.attendanceHistory || [];
  const currentUser = appState.currentUser || JSON.parse(localStorage.getItem('smart_campus_current_session') || '{}');
  const myRoll = currentUser.roll || (appState.profile ? appState.profile.roll : null);
  const isTeacher = currentUser.role === 'teacher';

  // Strict Data Isolation: If student, show ONLY this student's records!
  if (!isTeacher) {
    logs = myRoll ? logs.filter(item => item.roll === myRoll) : [];
  }

  // Filter logic
  const filtered = logs.filter(item => {
    const matchesDate = !dateFilter || item.date === dateFilter;
    const matchesSubject = subjectFilter === 'all' || item.subject === subjectFilter;
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    return matchesDate && matchesSubject && matchesStatus;
  });

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="5" class="p-6 text-center text-xs text-slate-400 font-medium">
          Ya criteria sathi kontahi attendance record sapadla nahi.
        </td>
      </tr>
    `;
    return;
  }

  tbody.innerHTML = filtered.map(log => {
    const isPresent = log.status === 'Present';
    return `
      <tr class="hover:bg-slate-50/70 transition">
        <td class="p-3 font-mono text-xs font-semibold text-slate-600">📅 ${log.date}</td>
        <td class="p-3 font-bold text-xs text-slate-900">${log.subject}</td>
        <td class="p-3 font-mono text-xs text-indigo-600 font-bold">${log.roll}</td>
        <td class="p-3 text-xs text-slate-700">${log.studentName || 'Student'}</td>
        <td class="p-3 text-right">
          <span class="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black ${isPresent ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-700'}">
            <span>${isPresent ? '✓' : '✗'}</span>
            <span>${log.status}</span>
          </span>
        </td>
      </tr>
    `;
  }).join('');
}

// ----------------- TEACHER ROLL-CALL MARKING MODAL -----------------
function openTeacherRollCallModal() {
  const user = appState.currentUser;
  if (!user || user.role !== 'teacher') {
    showToast('⛔ Only Faculty members can mark subject attendance.');
    return;
  }

  populateAttendanceFilters();
  const listContainer = document.getElementById('teacherModalStudentsList');
  const students = appState.studentsList || [];

  listContainer.innerHTML = students.map((s) => `
    <div class="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
      <div>
        <div class="text-xs font-bold text-slate-800">${s.name}</div>
        <div class="text-[10px] font-mono text-indigo-600 font-semibold">${s.roll}</div>
      </div>
      <div class="flex items-center gap-2">
        <label class="inline-flex items-center gap-1 cursor-pointer text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
          <input type="radio" name="modal_roll_status_${s.roll}" value="Present" checked class="accent-emerald-600">
          Present
        </label>
        <label class="inline-flex items-center gap-1 cursor-pointer text-xs font-bold text-rose-700 bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200">
          <input type="radio" name="modal_roll_status_${s.roll}" value="Absent" class="accent-rose-600">
          Absent
        </label>
      </div>
    </div>
  `).join('');

  document.getElementById('teacherRollCallModal').classList.remove('hidden');
}

function closeTeacherRollCallModal() {
  document.getElementById('teacherRollCallModal').classList.add('hidden');
}

function markAllModalStudents(present) {
  const students = appState.studentsList || [];
  students.forEach(s => {
    const radio = document.querySelector(`input[name="modal_roll_status_${s.roll}"][value="${present ? 'Present' : 'Absent'}"]`);
    if (radio) radio.checked = true;
  });
}

async function handleTeacherRollCallSubmit(e) {
  e.preventDefault();
  const user = appState.currentUser;
  if (!user || user.role !== 'teacher') {
    showToast('⛔ Permission Denied.');
    closeTeacherRollCallModal();
    return;
  }

  const subject = document.getElementById('teacherModalSubjectSelect').value;
  const date = document.getElementById('teacherModalAttendanceDate').value;

  if (!subject || !date) {
    showToast('Please select subject and date.');
    return;
  }

  const students = appState.studentsList || [];
  if (!appState.attendanceHistory) appState.attendanceHistory = [];

  let batchRecords = [];

  students.forEach(s => {
    const radio = document.querySelector(`input[name="modal_roll_status_${s.roll}"]:checked`);
    const status = radio ? radio.value : 'Present';

    appState.attendanceHistory = appState.attendanceHistory.filter(
      h => !(h.date === date && h.subject === subject && h.roll === s.roll)
    );

    const newLog = {
      id: 'att_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      date,
      subject,
      roll: s.roll,
      studentName: s.name,
      status
    };

    appState.attendanceHistory.unshift(newLog);
    batchRecords.push(newLog);
  });

  saveState();
  syncAttendanceWithLogs();
  closeTeacherRollCallModal();
  renderAttendanceList();
  renderAttendanceHistory();
  showToast(`✅ Attendance recorded for ${subject} on ${date}!`);

  if (window.fbDb && window.fbMethods) {
    Promise.all(batchRecords.map(rec => {
      return window.fbMethods.addDoc(window.fbMethods.collection(window.fbDb, "attendance_history"), {
        ...rec,
        timestamp: window.fbMethods.serverTimestamp()
      }).catch(() => {});
    })).catch(() => {});
  }
}

function adjustSubjectAttendance(subjectId, delta) {
  const user = appState.currentUser;
  if (!user || user.role !== 'teacher') {
    showToast('⛔ Only Faculty can manually adjust lecture counts.');
    return;
  }

  const subject = appState.attendance.subjects.find(s => s.id === subjectId);
  if (!subject) return;

  if (delta > 0) {
    subject.attended += 1;
    subject.total += 1;
    showToast(`Marked 1 lecture attended for ${subject.name}`);
  } else if (delta < 0 && subject.attended > 0) {
    subject.attended -= 1;
    showToast(`Deducted 1 lecture for ${subject.name}`);
  }

  syncAttendanceWithLogs();
  saveState();
  renderAttendanceList();
}





 else {
    showToast('❌ Invalid Attendance PIN');
  }
}
