// Multi-Tenant Isolated Storage & State Engine for Smart Campus (Cloud Firestore Hybrid Sync)

// Baseline template for newly registered students (Strictly Clean & Isolated)
function getInitialStudentData(user) {
  const name = user.name || 'New Student';
  const roll = user.roll || 'COMP-2026-NEW';
  const email = user.email || 'student@campus.edu';
  
  return {
    profile: {
      name: name,
      roll: roll,
      email: email,
      phone: user.phone || '+91 98765 00000',
      department: user.department || 'Computer Engineering'
    },
    attendance: {
      overallPercentage: 0,
      attended: 0,
      missed: 0,
      safeSubjects: 0,
      totalSubjects: 6,
      subjects: [
        { id: 1, name: 'Data Structures & Algorithms', attended: 0, total: 0, percent: 0 },
        { id: 2, name: 'Mathematics III', attended: 0, total: 0, percent: 0 },
        { id: 3, name: 'Operating Systems', attended: 0, total: 0, percent: 0 },
        { id: 4, name: 'Human-Computer Interaction', attended: 0, total: 0, percent: 0 },
        { id: 5, name: 'Database Management Systems', attended: 0, total: 0, percent: 0 },
        { id: 6, name: 'Computer Networks', attended: 0, total: 0, percent: 0 }
      ]
    },
    submissions: {}, // Key: assignmentId -> { fileName, submittedAt, status, note }
    documents: [],
    notifications: [
      { id: Date.now(), text: `🎓 Welcome to Smart Campus Portal, ${name}! Your student account is active.`, unread: true, time: 'Just now' }
    ]
  };
}

// Global master state (Shared timetable, master assignment prompts, faculty documents)
const GLOBAL_DEFAULT_STATE = {
  timetable: [
    {
      time: "09:00 - 10:30",
      Monday: "Data Structures (Lab 4B)",
      Tuesday: "Maths III (Room 102)",
      Wednesday: "Data Structures (Lab 4B)",
      Thursday: "Operating Systems (Lab 1)",
      Friday: "HCI Seminar (Hall 2)"
    },
    {
      time: "11:00 - 12:30",
      Monday: "Operating Systems (Lab 1)",
      Tuesday: "Database Systems (Lab 3)",
      Wednesday: "Maths III (Room 102)",
      Thursday: "Computer Networks (Room 201)",
      Friday: "Data Structures (Lab 4B)"
    },
    {
      time: "01:30 - 03:00",
      Monday: "Physics Lab",
      Tuesday: "HCI (Room 405)",
      Wednesday: "Software Engg (Room 304)",
      Thursday: "Library / Self Study",
      Friday: "Project Prep (Lab 4B)"
    },
    {
      time: "03:15 - 04:45",
      Monday: "Mentorship Session",
      Tuesday: "Remedial Coding",
      Wednesday: "Elective Lab",
      Thursday: "Sports / Extra Curricular",
      Friday: "Faculty Review"
    }
  ],
  assignments: [
    { id: 'asgn_1', title: 'Database Normalization Project', subject: 'DBMS', due: 'Tomorrow 11:59 PM', status: 'Pending' },
    { id: 'asgn_2', title: 'Tree Traversal Algorithms in C++', subject: 'Data Structures', due: 'In 3 days', status: 'Pending' },
    { id: 'asgn_3', title: 'Virtual Memory Implementation Report', subject: 'Operating Systems', due: 'Next week', status: 'Pending' }
  ],
  studentsList: [
    { roll: "COMP-2026-018", name: "Jay Nitin Bidkar" },
    { roll: "COMP-2026-019", name: "Rahul Deshmukh" },
    { roll: "COMP-2026-020", name: "Sneha Patil" }
  ],
  attendanceHistory: [],
  teachingSchedule: [
    { id: 1, day: "Monday", time: "09:00 AM - 10:30 AM", subject: "Data Structures & Algorithms", room: "Lab 4B" },
    { id: 2, day: "Tuesday", time: "11:00 AM - 12:30 PM", subject: "Database Management Systems", room: "Room 302" }
  ],
  facultyDocuments: [
    { id: 'fac_1', title: "EndSem_DS_QuestionPaper_Draft.pdf", category: "qp", subject: "Data Structures", date: "Nov 01", size: "2.1 MB" },
    { id: 'fac_2', title: "Semester_V_Curriculum_Blueprint.docx", category: "syllabus", subject: "Computer Engg", date: "Oct 29", size: "1.4 MB" }
  ]
};

// Identify active user session key
function getCurrentUserKey() {
  const current = JSON.parse(localStorage.getItem('smart_campus_current_session') || 'null');
  if (current && current.email) {
    return 'smart_campus_user_' + encodeURIComponent(current.email.toLowerCase().trim());
  }
  return 'smart_campus_user_guest';
}

function loadAppState() {
  const globalData = JSON.parse(localStorage.getItem('smart_campus_global_state') || 'null') || GLOBAL_DEFAULT_STATE;
  const currentSession = JSON.parse(localStorage.getItem('smart_campus_current_session') || 'null');
  
  const userKey = getCurrentUserKey();
  let userScopedData = JSON.parse(localStorage.getItem(userKey) || 'null');
  
  if (!userScopedData) {
    userScopedData = getInitialStudentData(currentSession || {});
    localStorage.setItem(userKey, JSON.stringify(userScopedData));
  }

  return {
    currentUser: currentSession,
    activeRole: currentSession ? currentSession.role : 'student',
    
    // User-Specific (Strictly Isolated)
    profile: userScopedData.profile,
    attendance: userScopedData.attendance,
    submissions: userScopedData.submissions || {},
    documents: userScopedData.documents || [],
    notifications: userScopedData.notifications || [],
    
    // Global Shared Data
    timetable: globalData.timetable || GLOBAL_DEFAULT_STATE.timetable,
    assignments: globalData.assignments || GLOBAL_DEFAULT_STATE.assignments,
    studentsList: globalData.studentsList || GLOBAL_DEFAULT_STATE.studentsList,
    attendanceHistory: globalData.attendanceHistory || GLOBAL_DEFAULT_STATE.attendanceHistory,
    teachingSchedule: globalData.teachingSchedule || GLOBAL_DEFAULT_STATE.teachingSchedule,
    facultyDocuments: globalData.facultyDocuments || GLOBAL_DEFAULT_STATE.facultyDocuments
  };
}

let appState = loadAppState();

function saveState() {
  const userKey = getCurrentUserKey();
  const userScopedData = {
    profile: appState.profile,
    attendance: appState.attendance,
    submissions: appState.submissions || {},
    documents: appState.documents || [],
    notifications: appState.notifications || []
  };
  localStorage.setItem(userKey, JSON.stringify(userScopedData));

  const globalData = {
    timetable: appState.timetable,
    assignments: appState.assignments,
    studentsList: appState.studentsList,
    attendanceHistory: appState.attendanceHistory,
    teachingSchedule: appState.teachingSchedule,
    facultyDocuments: appState.facultyDocuments
  };
  localStorage.setItem('smart_campus_global_state', JSON.stringify(globalData));
  
  if (appState.currentUser) {
    localStorage.setItem('smart_campus_current_session', JSON.stringify(appState.currentUser));
    
    // Cloud Firestore Sync (Mirror to cloud database seamlessly)
    if (window.fbDb && window.fbMethods && appState.currentUser.uid) {
      try {
        const userDocRef = window.fbMethods.doc(window.fbDb, "users", appState.currentUser.uid);
        window.fbMethods.setDoc(userDocRef, {
          profile: appState.profile,
          attendance: appState.attendance,
          submissions: appState.submissions || {},
          updatedAt: window.fbMethods.serverTimestamp()
        }, { merge: true }).catch(() => {});
      } catch(e) {}
    }
  }
}

// Global Header & Profile Dynamic Synchronization
function syncHeaderUserProfile() {
  const current = appState.currentUser || JSON.parse(localStorage.getItem('smart_campus_current_session') || 'null');
  if (!current) return;

  const name = current.name || (appState.profile ? appState.profile.name : 'Student');
  const role = current.role || 'student';

  const headerName = document.getElementById('headerUserName');
  const headerRole = document.getElementById('headerUserRole');

  if (headerName) headerName.innerText = name;
  if (headerRole) headerRole.innerText = role === 'teacher' ? 'Faculty / Teacher' : 'Student';
}

function showToast(msg) {
  const toast = document.getElementById('toast');
  if (!toast) return;
  toast.innerText = msg;
  toast.classList.remove('translate-y-20', 'opacity-0');
  setTimeout(() => {
    toast.classList.add('translate-y-20', 'opacity-0');
  }, 2600);
}

document.addEventListener('DOMContentLoaded', () => {
  syncHeaderUserProfile();
  
  // Real-time Firestore Cloud listener for active user profile & attendance
  if (window.fbDb && window.fbMethods && appState.currentUser && appState.currentUser.uid) {
    try {
      const uRef = window.fbMethods.doc(window.fbDb, "users", appState.currentUser.uid);
      window.fbMethods.onSnapshot(uRef, (snap) => {
        if (snap.exists()) {
          const cData = snap.data();
          let changed = false;
          if (cData.profile && JSON.stringify(cData.profile) !== JSON.stringify(appState.profile)) {
            appState.profile = { ...appState.profile, ...cData.profile };
            changed = true;
          }
          if (cData.attendance && cData.attendance.totalSubjects && (!appState.attendance || !appState.attendance.totalSubjects)) {
            appState.attendance = cData.attendance;
            changed = true;
          }
          if (changed) {
            syncHeaderUserProfile();
          }
        }
      });
    } catch(e) {}
  }
});
