// Teacher & Faculty Command Center Master Engine
let selectedFacultyFile = null;

// Default teacher's personal teaching schedule routine
const DEFAULT_TEACHING_SCHEDULE = [
  { id: 1, day: "Monday", time: "09:00 AM - 10:30 AM", subject: "Data Structures & Algorithms", room: "Lab 4B (Advanced Computing)" },
  { id: 2, day: "Monday", time: "11:00 AM - 12:30 PM", subject: "Operating Systems Lab", room: "Lab 1 (Systems Lab)" },
  { id: 3, day: "Tuesday", time: "11:00 AM - 12:30 PM", subject: "Database Management Systems", room: "Classroom 302" },
  { id: 4, day: "Wednesday", time: "09:00 AM - 10:30 AM", subject: "Data Structures Theory", room: "Seminar Hall 1" },
  { id: 5, day: "Thursday", time: "01:30 PM - 03:00 PM", subject: "Project Mentorship & Review", room: "Project Lab" },
  { id: 6, day: "Friday", time: "11:00 AM - 12:30 PM", subject: "Data Structures Lab Batch B", room: "Lab 4B" }
];

// Default faculty confidential documents
const DEFAULT_FACULTY_DOCS = [
  { id: 101, title: "EndSem_DS_QuestionPaper_Draft.pdf", category: "qp", subject: "Data Structures", date: "Nov 01", size: "2.1 MB" },
  { id: 102, title: "Semester_V_Curriculum_Blueprint.docx", category: "syllabus", subject: "Computer Engg", date: "Oct 29", size: "1.4 MB" },
  { id: 103, title: "Mini_Project_Evaluation_Rubric.xlsx", category: "rubric", subject: "Academic Evaluation", date: "Oct 25", size: "850 KB" },
  { id: 104, title: "University_Exam_Duty_Circular.pdf", category: "circular", subject: "Administration", date: "Oct 20", size: "920 KB" }
];

if (!appState.teachingSchedule) {
  appState.teachingSchedule = DEFAULT_TEACHING_SCHEDULE;
  saveState();
}

if (!appState.facultyDocuments) {
  appState.facultyDocuments = DEFAULT_FACULTY_DOCS;
  saveState();
}

document.addEventListener('DOMContentLoaded', () => {
  // Ensure only faculty can access this dashboard
  const user = appState.currentUser;
  if (user && user.role === 'student') {
    showToast("Redirecting to Student Dashboard...");
    window.location.href = 'dashboard.html';
    return;
  }

  initTeacherCloudSync();
  initLiveCalendarAndOverview();
  renderTeachingSchedule();
  setupAttendanceMarkerForm();
  renderMasterTimetable();
  renderFacultyDocsGrid('all');
});

// ----------------- TAB SWITCHER -----------------
function switchTeacherTab(tabName) {
  const tabs = ['overview', 'schedule', 'attendance', 'timetable', 'documents'];
  tabs.forEach(t => {
    const btn = document.getElementById(`tabBtn${t.charAt(0).toUpperCase() + t.slice(1)}`) ||
                (t === 'overview' ? document.getElementById('tabBtnFacultyOverview') :
                 t === 'schedule' ? document.getElementById('tabBtnTeachingSchedule') :
                 t === 'attendance' ? document.getElementById('tabBtnRollCallMarker') :
                 t === 'timetable' ? document.getElementById('tabBtnMasterTimetable') :
                 document.getElementById('tabBtnFacultyDocs'));

    const panel = document.getElementById(`teacherTab-${t}`);
    if (btn) {
      if (t === tabName) {
        btn.className = 'py-1.5 px-3 rounded-lg bg-indigo-50 text-indigo-700 font-bold transition';
      } else {
        btn.className = 'py-1.5 px-3 rounded-lg text-slate-600 hover:text-slate-900 font-bold transition';
      }
    }
    if (panel) {
      if (t === tabName) panel.classList.remove('hidden');
      else panel.classList.add('hidden');
    }
  });

  if (tabName === 'schedule') renderTeachingSchedule();
  if (tabName === 'attendance') setupAttendanceMarkerForm();
  if (tabName === 'timetable') renderMasterTimetable();
  if (tabName === 'documents') renderFacultyDocsGrid('all');
}

// ----------------- CLOUD SYNC -----------------
function initTeacherCloudSync() {
  if (window.fbDb && window.fbMethods) {
    

    // 2. Listen for master timetable sync
    const ttDoc = window.fbMethods.doc(window.fbDb, "system", "timetable");
    window.fbMethods.onSnapshot(ttDoc, (snap) => {
      if (snap.exists() && snap.data().slots) {
        appState.timetable = snap.data().slots;
        saveState();
        renderMasterTimetable();
      }
    });

    // 3. Listen for faculty documents
    window.fbMethods.onSnapshot(window.fbMethods.collection(window.fbDb, "faculty_documents"), (snap) => {
      snap.docChanges().forEach((change) => {
        if (change.type === "added") {
          const docData = change.doc.data();
          const exists = appState.facultyDocuments.some(d => d.id === change.doc.id || d.title === docData.title);
          if (!exists) {
            appState.facultyDocuments.unshift({
              id: change.doc.id,
              title: docData.title,
              category: docData.category,
              subject: docData.subject,
              size: docData.size || '1.8 MB',
              date: docData.date || 'Today',
              downloadUrl: docData.downloadUrl || null
            });
            saveState();
            renderFacultyDocsGrid('all');
          }
        }
      });
    });
  }
}

// ----------------- 1. LIVE DYNAMIC CALENDAR & OVERVIEW ENGINE -----------------
let calendarViewDate = new Date(); // Tracks displayed month/year
let calendarSelectedDate = new Date(); // Tracks selected date

function initLiveCalendarAndOverview() {
  updateTeacherDateCards();
  renderLiveCalendar();
  renderSelectedDayTimetable();
  renderTeacherOverviewTable();

  // Re-check live lecture badges every minute
  setInterval(() => {
    updateTeacherDateCards();
    renderSelectedDayTimetable();
  }, 60000);
}

function updateTeacherDateCards() {
  const now = new Date();
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  const dayName = days[now.getDay()];
  const dateFormatted = `${dayName}, ${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;

  const dateDisplay = document.getElementById('teacherOverviewDateDisplay');
  const dayTag = document.getElementById('teacherOverviewDayTag');
  const slotsCountEl = document.getElementById('teacherTodaySlotsCount');

  if (dateDisplay) dateDisplay.innerText = dateFormatted;

  const timetable = appState.timetable || [];
  // Count active lectures for today if weekday
  if (dayName === 'Sunday' || dayName === 'Saturday') {
    if (dayTag) dayTag.innerText = "Weekend • Campus Closed";
    if (slotsCountEl) slotsCountEl.innerText = "Next batch lectures resume on Monday.";
  } else {
    const todaySlots = timetable.filter(slot => slot[dayName] && slot[dayName] !== '-');
    if (dayTag) dayTag.innerText = `Active Day • ${todaySlots.length} Lectures`;
    if (slotsCountEl) slotsCountEl.innerText = `${todaySlots.length} sessions scheduled across campus today.`;
  }
}

function changeCalendarMonth(delta) {
  calendarViewDate.setMonth(calendarViewDate.getMonth() + delta);
  renderLiveCalendar();
}

function resetCalendarToToday() {
  calendarViewDate = new Date();
  calendarSelectedDate = new Date();
  renderLiveCalendar();
  renderSelectedDayTimetable();
}

function selectCalendarDate(year, month, day) {
  calendarSelectedDate = new Date(year, month, day);
  renderLiveCalendar();
  renderSelectedDayTimetable();
}

function renderLiveCalendar() {
  const monthYearEl = document.getElementById('liveCalendarMonthYear');
  const gridEl = document.getElementById('liveCalendarDaysGrid');
  if (!monthYearEl || !gridEl) return;

  const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  const year = calendarViewDate.getFullYear();
  const month = calendarViewDate.getMonth();

  monthYearEl.innerText = `${monthNames[month]} ${year}`;

  const firstDayIndex = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const prevMonthDays = new Date(year, month, 0).getDate();

  const today = new Date();
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;

  let daysHtml = '';

  // Previous month trailing days
  for (let i = firstDayIndex; i > 0; i--) {
    const prevDate = prevMonthDays - i + 1;
    daysHtml += `<div class="p-2 text-center text-slate-300 font-medium cursor-default">${prevDate}</div>`;
  }

  // Current month active days
  for (let d = 1; d <= daysInMonth; d++) {
    const isToday = isCurrentMonth && today.getDate() === d;
    const isSelected = calendarSelectedDate.getFullYear() === year &&
                       calendarSelectedDate.getMonth() === month &&
                       calendarSelectedDate.getDate() === d;

    let dayClasses = "p-2 rounded-xl text-center font-bold transition cursor-pointer hover:bg-indigo-50 hover:text-indigo-700 ";
    if (isSelected) {
      dayClasses += "bg-indigo-600 text-white hover:bg-indigo-700 hover:text-white shadow-sm ";
    } else if (isToday) {
      dayClasses += "ring-2 ring-indigo-500 text-indigo-700 font-black bg-indigo-50/50 ";
    } else {
      dayClasses += "text-slate-700 ";
    }

    daysHtml += `
      <div onclick="selectCalendarDate(${year}, ${month}, ${d})" class="${dayClasses}">
        ${d}
      </div>
    `;
  }

  gridEl.innerHTML = daysHtml;
}

function parseSlotTimeToMinutes(timeStr) {
  const clean = timeStr.trim().toUpperCase();
  const parts = clean.split(' ');
  const timePart = parts[0];
  const modifier = parts[1];
  let [hours, minutes] = timePart.split(':').map(Number);
  if (modifier === 'PM' && hours < 12) hours += 12;
  if (modifier === 'AM' && hours === 12) hours = 0;
  return hours * 60 + minutes;
}

function renderSelectedDayTimetable() {
  const container = document.getElementById('selectedDayTimetableList');
  const titleEl = document.getElementById('selectedDateTitle');
  const badgeEl = document.getElementById('selectedDayBadge');
  const subEl = document.getElementById('selectedDateSub');
  if (!container) return;

  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  const dayName = days[calendarSelectedDate.getDay()];
  const dateFormatted = `${calendarSelectedDate.getDate()} ${months[calendarSelectedDate.getMonth()]} ${calendarSelectedDate.getFullYear()}`;

  const today = new Date();
  const isToday = today.toDateString() === calendarSelectedDate.toDateString();

  if (titleEl) titleEl.innerText = isToday ? "Schedule for Today" : `Schedule for ${dateFormatted}`;
  if (badgeEl) badgeEl.innerText = dayName;
  if (subEl) subEl.innerText = isToday ? "Real-time live session sync active" : `Academic schedule for ${dayName}`;

  // If weekend, show weekend status message
  if (dayName === 'Sunday' || dayName === 'Saturday') {
    container.innerHTML = `
      <div class="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200/80">
        <span class="text-3xl">☕</span>
        <h4 class="text-xs font-bold text-slate-800 mt-2">Weekend (${dayName}) - No Classes Scheduled</h4>
        <p class="text-[11px] text-slate-400 mt-0.5">Faculty and students have scheduled holiday. Campus lab access available for self-study.</p>
        <button onclick="selectCalendarDate(${calendarSelectedDate.getFullYear()}, ${calendarSelectedDate.getMonth()}, ${calendarSelectedDate.getDate() + (dayName === 'Sunday' ? 1 : 2)})" class="mt-3 px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold rounded-xl transition">
          View Upcoming Monday Schedule →
        </button>
      </div>
    `;
    return;
  }

  const timetable = appState.timetable || [];
  const currentMinutes = today.getHours() * 60 + today.getMinutes();

  const slotsForDay = timetable.map((slot, idx) => {
    const lectureDesc = slot[dayName] || '-';
    let status = 'Scheduled';
    let badgeStyle = 'bg-slate-100 text-slate-700';
    let borderStyle = 'border-slate-200/80 bg-white';

    if (slot.time) {
      const parts = slot.time.split(' - ');
      if (parts.length === 2) {
        const startMins = parseSlotTimeToMinutes(parts[0]);
        const endMins = parseSlotTimeToMinutes(parts[1]);

        if (isToday) {
          if (currentMinutes >= startMins && currentMinutes <= endMins) {
            status = 'Live Now';
            badgeStyle = 'bg-rose-100 text-rose-700 font-extrabold animate-pulse';
            borderStyle = 'border-rose-300 bg-rose-50/50 shadow-sm ring-1 ring-rose-400/30';
          } else if (currentMinutes < startMins) {
            status = 'Upcoming';
            badgeStyle = 'bg-emerald-100 text-emerald-800 font-bold';
            borderStyle = 'border-emerald-200 bg-emerald-50/30';
          } else {
            status = 'Completed';
            badgeStyle = 'bg-blue-100 text-blue-700 font-semibold';
            borderStyle = 'border-slate-100 bg-slate-50 text-slate-400';
          }
        }
      }
    }

    return `
      <div class="p-3.5 rounded-2xl ${borderStyle} border flex items-center justify-between gap-3 hover:shadow-sm transition">
        <div class="flex items-center gap-3">
          <div class="text-xs font-mono font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1.5 rounded-xl">
            ⏰ ${slot.time}
          </div>
          <div>
            <div class="text-xs font-black text-slate-900">${lectureDesc}</div>
            <div class="text-[10px] text-slate-400 mt-0.5">Computer Engineering • Semester V</div>
          </div>
        </div>

        <div>
          <span class="text-[10px] px-2.5 py-1 rounded-full ${badgeStyle}">
            ${status}
          </span>
        </div>
      </div>
    `;
  });

  container.innerHTML = slotsForDay.join('');
}

function renderTeacherOverviewTable() {
  const tbody = document.getElementById('facultyRollCallTable');
  if (!tbody) return;

  const students = appState.studentsList || [
    { roll: 'COMP-2026-018', name: 'Jay Nitin Bidkar' },
    { roll: 'COMP-2026-019', name: 'Rahul Deshmukh' },
    { roll: 'COMP-2026-020', name: 'Sneha Patil' },
    { roll: 'COMP-2026-021', name: 'Aditya Kulkarni' },
    { roll: 'COMP-2026-022', name: 'Pooja Sharma' }
  ];

  const history = appState.attendanceHistory || [];

  tbody.innerHTML = students.map((s) => {
    const studentLogs = history.filter(h => h.roll && h.roll.toLowerCase() === s.roll.toLowerCase());
    const total = studentLogs.length;
    const present = studentLogs.filter(h => h.status === 'Present').length;
    const percent = total > 0 ? Math.round((present / total) * 100) : 85;
    const isSafe = percent >= 75;
    return `
      <tr class="hover:bg-slate-50 transition">
        <td class="py-2.5 font-mono font-bold text-slate-700">${s.roll}</td>
        <td class="py-2.5 font-bold text-slate-800">${s.name}</td>
        <td class="py-2.5 text-slate-500">Computer Engineering (Semester V)</td>
        <td class="py-2.5 font-black ${isSafe ? 'text-emerald-600' : 'text-rose-600'}">${percent}%</td>
        <td class="py-2.5 text-right">
          <button onclick="switchTeacherTab('attendance')" class="px-2.5 py-1 bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 rounded-lg font-bold text-[10px] transition">Mark Attendance</button>
        </td>
      </tr>
    `;
  }).join('');
}

// ----------------- 2. TEACHER'S PERSONAL TEACHING SCHEDULE -----------------
function renderTeachingSchedule() {
  const container = document.getElementById('teacherPersonalScheduleGrid');
  if (!container) return;

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const schedule = appState.teachingSchedule || [];

  container.innerHTML = days.map(day => {
    const daySlots = schedule.filter(s => s.day === day);
    return `
      <div class="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm flex flex-col justify-between">
        <div>
          <div class="flex items-center justify-between pb-2 mb-3 border-b border-slate-100">
            <h4 class="text-xs font-black text-slate-900 uppercase tracking-wider">${day}</h4>
            <span class="text-[10px] px-2 py-0.5 rounded-full font-bold bg-indigo-50 text-indigo-700">${daySlots.length} Slots</span>
          </div>

          <div class="space-y-3">
            ${daySlots.length === 0 ? `
              <div class="text-[11px] text-slate-400 py-4 text-center italic">No lecture scheduled</div>
            ` : daySlots.map(slot => `
              <div class="p-2.5 rounded-xl bg-slate-50 border border-slate-100 hover:border-indigo-200 transition">
                <div class="text-[10px] font-mono font-bold text-indigo-600">⏰ ${slot.time}</div>
                <div class="text-xs font-bold text-slate-800 mt-1">${slot.subject}</div>
                <div class="text-[10px] text-slate-500 mt-0.5">📍 ${slot.room}</div>
                <div class="mt-2 flex justify-end">
                  <button onclick="deletePersonalScheduleSlot(${slot.id})" title="Remove Slot" class="text-[10px] text-slate-400 hover:text-rose-600 font-bold">Remove</button>
                </div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;
  }).join('');
}

function openAddPersonalScheduleModal() {
  document.getElementById('personalScheduleModal').classList.remove('hidden');
}

function closeAddPersonalScheduleModal() {
  document.getElementById('personalScheduleModal').classList.add('hidden');
}

function handlePersonalScheduleSave(e) {
  e.preventDefault();
  const day = document.getElementById('persSchedDay').value;
  const time = document.getElementById('persSchedTime').value.trim();
  const subject = document.getElementById('persSchedSubject').value.trim();
  const room = document.getElementById('persSchedRoom').value.trim();

  const newSlot = {
    id: Date.now(),
    day,
    time,
    subject,
    room
  };

  appState.teachingSchedule.push(newSlot);
  saveState();
  closeAddPersonalScheduleModal();
  renderTeachingSchedule();
  showToast(`✅ Added ${subject} on ${day} to your teaching schedule!`);
}

function deletePersonalScheduleSlot(id) {
  appState.teachingSchedule = appState.teachingSchedule.filter(s => s.id !== id);
  saveState();
  renderTeachingSchedule();
  showToast("Lecture slot removed from your schedule.");
}

// ----------------- 3. ATTENDANCE MARKER (ROLL-CALL & STUDENT ROSTER EDIT) -----------------
function setupAttendanceMarkerForm() {
  const subjectSelect = document.getElementById('teacherAttendanceSubjectSelect');
  const dateInput = document.getElementById('teacherAttendanceDateInput');

  const subjects = (appState.attendance && appState.attendance.subjects) || [
    { name: "Data Structures & Algorithms" },
    { name: "Mathematics III" },
    { name: "Operating Systems" },
    { name: "Human-Computer Interaction" },
    { name: "Database Management Systems" },
    { name: "Computer Networks" }
  ];

  if (subjectSelect) {
    const currentSub = subjectSelect.value;
    subjectSelect.innerHTML = subjects.map(s => `<option value="${s.name}">${s.name}</option>`).join('');
    if (currentSub) subjectSelect.value = currentSub;
  }

  if (dateInput && !dateInput.value) {
    dateInput.value = new Date().toISOString().split('T')[0];
  }

  loadDateAttendanceStatus();
}

function loadDateAttendanceStatus() {
  const rollList = document.getElementById('teacherAttendanceRollList');
  const subjectSelect = document.getElementById('teacherAttendanceSubjectSelect');
  const dateInput = document.getElementById('teacherAttendanceDateInput');
  if (!rollList || !subjectSelect || !dateInput) return;

  const subject = subjectSelect.value;
  const date = dateInput.value;

  const students = appState.studentsList || [
    { roll: "COMP-2026-018", name: "Jay Nitin Bidkar" },
    { roll: "COMP-2026-019", name: "Rahul Deshmukh" },
    { roll: "COMP-2026-020", name: "Sneha Patil" },
    { roll: "COMP-2026-021", name: "Aditya Kulkarni" },
    { roll: "COMP-2026-022", name: "Pooja Sharma" }
  ];

  const history = appState.attendanceHistory || [];

  rollList.innerHTML = students.map((s, idx) => {
    // Check if attendance already recorded for this date & subject
    const existingLog = history.find(h => h.date === date && h.subject === subject && h.roll === s.roll);
    const isPresent = existingLog ? (existingLog.status === 'Present') : true;

    return `
      <div class="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:border-indigo-300 transition">
        <!-- Student Info & Edit Buttons -->
        <div class="flex items-center gap-3">
          <div class="w-8 h-8 rounded-xl bg-slate-100 flex items-center justify-center font-bold text-xs text-slate-700">
            ${idx + 1}
          </div>
          <div>
            <div class="flex items-center gap-2">
              <span class="text-xs font-black text-slate-900">${s.name}</span>
              <button type="button" onclick="openEditStudentModal('${s.roll}', '${s.name}')" title="Edit Student Name / Roll No" class="p-1 text-slate-400 hover:text-indigo-600 rounded">
                ✏️
              </button>
              <button type="button" onclick="deleteStudentFromRoster('${s.roll}')" title="Delete Student" class="p-1 text-slate-400 hover:text-rose-600 rounded">
                🗑️
              </button>
            </div>
            <div class="text-[11px] font-mono font-bold text-indigo-600 mt-0.5">${s.roll}</div>
          </div>
        </div>

        <!-- Attendance Action Buttons (Present vs Absent Radio Toggle) -->
        <div class="flex items-center gap-2">
          <label class="inline-flex items-center gap-1.5 cursor-pointer text-xs font-bold px-3 py-1.5 rounded-xl border transition ${isPresent ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm' : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'}">
            <input type="radio" name="teacher_roll_status_${s.roll}" value="Present" ${isPresent ? 'checked' : ''} onchange="updateRadioStyles('${s.roll}')" class="hidden">
            <span>✓ Present</span>
          </label>

          <label class="inline-flex items-center gap-1.5 cursor-pointer text-xs font-bold px-3 py-1.5 rounded-xl border transition ${!isPresent ? 'bg-rose-600 text-white border-rose-600 shadow-sm' : 'bg-rose-50 text-rose-800 border-rose-200 hover:bg-rose-100'}">
            <input type="radio" name="teacher_roll_status_${s.roll}" value="Absent" ${!isPresent ? 'checked' : ''} onchange="updateRadioStyles('${s.roll}')" class="hidden">
            <span>✗ Absent</span>
          </label>
        </div>
      </div>
    `;
  }).join('');
}

function updateRadioStyles(roll) {
  loadDateAttendanceStatus();
}

function markAllTeacherAttendance(present) {
  const students = appState.studentsList || [];
  students.forEach(s => {
    const radio = document.querySelector(`input[name="teacher_roll_status_${s.roll}"][value="${present ? 'Present' : 'Absent'}"]`);
    if (radio) radio.checked = true;
  });
  loadDateAttendanceStatus();
}

// Save & Update Attendance Records
async function handleTeacherAttendanceBatchSave(e) {
  if (e && e.preventDefault) e.preventDefault();
  const subjectEl = document.getElementById('teacherAttendanceSubjectSelect');
  const dateEl = document.getElementById('teacherAttendanceDateInput');
  const submitBtn = e && e.target ? e.target.querySelector('button[type="submit"]') : null;

  const subject = subjectEl ? subjectEl.value : '';
  const date = dateEl ? dateEl.value : '';

  if (!subject || !date) {
    showToast("Please choose subject and date.");
    return false;
  }

  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span>Saving...</span><span class="ml-2 animate-spin">⏳</span>';
  }

  const students = appState.studentsList || [];
  if (!appState.attendanceHistory) appState.attendanceHistory = [];

  let batchRecords = [];
  let presentCount = 0;
  let absentCount = 0;

  students.forEach(s => {
    const radio = document.querySelector(`input[name="teacher_roll_status_${s.roll}"]:checked`);
    const status = radio ? radio.value : 'Present';

    if (status === 'Present') presentCount++;
    else absentCount++;

    // Remove old log for this student on this date and subject
    appState.attendanceHistory = appState.attendanceHistory.filter(
      h => !(h.date === date && h.subject === subject && h.roll === s.roll)
    );

    const logItem = {
      id: 'att_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      date,
      subject,
      roll: s.roll,
      studentName: s.name,
      status
    };

    appState.attendanceHistory.unshift(logItem);
    batchRecords.push(logItem);
  });

  // Cross-Partition Attendance Sync:
  // Update each student's isolated localStorage partition so when that student logs in,
  // their percentage and safe/shortfall status reflects this attendance!
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const storageKey = localStorage.key(i);
      if (storageKey && storageKey.startsWith('smart_campus_user_')) {
        const studentBucket = JSON.parse(localStorage.getItem(storageKey) || 'null');
        if (studentBucket && studentBucket.profile && studentBucket.attendance) {
          const studentRoll = studentBucket.profile.roll;
          // Check if this student was in the attendance batch
          const logForStudent = batchRecords.find(b => b.roll === studentRoll);
          if (logForStudent) {
            let sub = studentBucket.attendance.subjects.find(item => item.name === subject);
            if (!sub) {
              sub = { id: Date.now(), name: subject, attended: 0, total: 0, percent: 0 };
              studentBucket.attendance.subjects.push(sub);
            }
            sub.total = (sub.total || 0) + 1;
            if (logForStudent.status === 'Present') {
              sub.attended = (sub.attended || 0) + 1;
            }
            sub.percent = Math.round((sub.attended / sub.total) * 100);

            // Recalculate overall
            let totalAtt = 0;
            let totalClass = 0;
            let safeSubCount = 0;
            studentBucket.attendance.subjects.forEach(stItem => {
              totalAtt += stItem.attended || 0;
              totalClass += stItem.total || 0;
              if (stItem.percent >= 75) safeSubCount++;
            });
            studentBucket.attendance.attended = totalAtt;
            studentBucket.attendance.missed = Math.max(0, totalClass - totalAtt);
            studentBucket.attendance.overallPercentage = totalClass > 0 ? Math.round((totalAtt / totalClass) * 100) : 0;
            studentBucket.attendance.safeSubjects = safeSubCount;

            localStorage.setItem(storageKey, JSON.stringify(studentBucket));
          }
        }
      }
    }
  } catch(err) {
    console.warn("Cross-partition sync notice:", err);
  }

  saveState();
  loadDateAttendanceStatus();
  showToast(`✅ Attendance Recorded: ${presentCount} Present, ${absentCount} Absent for ${subject} (${date})!`);

  if (submitBtn) {
    submitBtn.disabled = false;
    submitBtn.innerHTML = '💾 Save & Update Attendance Records';
  }

  // Non-blocking Cloud Firestore background write
  if (window.fbDb && window.fbMethods) {
    Promise.all(batchRecords.map(rec => {
      return window.fbMethods.addDoc(window.fbMethods.collection(window.fbDb, "attendance_history"), {
        ...rec,
        timestamp: window.fbMethods.serverTimestamp()
      }).catch(() => {});
    })).catch(() => {});
  }

  return false;
}

// ----------------- STUDENT ROSTER MANAGEMENT (ADD / EDIT / DELETE) -----------------
function openAddNewStudentModal() {
  document.getElementById('studentManageModalTitle').innerText = "Add New Student to Roster";
  document.getElementById('studentEditOriginalRoll').value = "";
  document.getElementById('manageStudentRoll').value = "";
  document.getElementById('manageStudentName').value = "";
  document.getElementById('studentManageModal').classList.remove('hidden');
}

function openEditStudentModal(roll, name) {
  document.getElementById('studentManageModalTitle').innerText = "Edit Student Information";
  document.getElementById('studentEditOriginalRoll').value = roll;
  document.getElementById('manageStudentRoll').value = roll;
  document.getElementById('manageStudentName').value = name;
  document.getElementById('studentManageModal').classList.remove('hidden');
}

function closeStudentManageModal() {
  document.getElementById('studentManageModal').classList.add('hidden');
}

function handleSaveStudentRoster(e) {
  e.preventDefault();
  const origRoll = document.getElementById('studentEditOriginalRoll').value;
  const newRoll = document.getElementById('manageStudentRoll').value.trim();
  const newName = document.getElementById('manageStudentName').value.trim();

  if (!newRoll || !newName) return;

  if (!appState.studentsList) appState.studentsList = [];

  if (origRoll) {
    // Edit existing student
    const student = appState.studentsList.find(s => s.roll === origRoll);
    if (student) {
      student.roll = newRoll;
      student.name = newName;
      // Also update history records with new name/roll
      if (appState.attendanceHistory) {
        appState.attendanceHistory.forEach(h => {
          if (h.roll === origRoll) {
            h.roll = newRoll;
            h.studentName = newName;
          }
        });
      }
      showToast(`Student updated to ${newName} (${newRoll})`);
    }
  } else {
    // Add new student
    const exists = appState.studentsList.some(s => s.roll.toLowerCase() === newRoll.toLowerCase());
    if (exists) {
      showToast("Student with this roll number already exists!");
      return;
    }
    appState.studentsList.push({ roll: newRoll, name: newName });
    showToast(`Added ${newName} (${newRoll}) to roster!`);
  }

  saveState();
  closeStudentManageModal();
  loadDateAttendanceStatus();
  initLiveCalendarAndOverview();
}

function deleteStudentFromRoster(roll) {
  if (confirm(`Are you sure you want to remove student with Roll No: ${roll}?`)) {
    appState.studentsList = appState.studentsList.filter(s => s.roll !== roll);
    saveState();
    loadDateAttendanceStatus();
    initLiveCalendarAndOverview();
    showToast(`Student ${roll} removed from class roster.`);
  }
}

// ----------------- 4. MASTER TIMETABLE EDITOR -----------------
function renderMasterTimetable() {
  const tbody = document.getElementById('teacherMasterTimetableBody');
  if (!tbody) return;

  const timetable = appState.timetable || [];
  tbody.innerHTML = timetable.map((row, idx) => `
    <tr class="hover:bg-slate-50 transition">
      <td class="p-3 font-mono font-bold text-slate-400 bg-slate-50/50">${row.time}</td>
      <td class="p-3 ${row.Monday && row.Monday.includes('Data') ? 'bg-indigo-50/60 font-semibold text-indigo-900' : ''}">${row.Monday || '-'}</td>
      <td class="p-3">${row.Tuesday || '-'}</td>
      <td class="p-3 ${row.Wednesday && row.Wednesday.includes('Data') ? 'bg-indigo-50/60 font-semibold text-indigo-900' : ''}">${row.Wednesday || '-'}</td>
      <td class="p-3">${row.Thursday || '-'}</td>
      <td class="p-3">${row.Friday || '-'}</td>
    </tr>
  `).join('');
}

function openMasterTimetableEditModal() {
  document.getElementById('masterTimetableModal').classList.remove('hidden');
}

function closeMasterTimetableEditModal() {
  document.getElementById('masterTimetableModal').classList.add('hidden');
}

async function handleMasterTimetableSave(e) {
  e.preventDefault();
  const day = document.getElementById('masterTtDay').value;
  const slotIdx = parseInt(document.getElementById('masterTtSlotIndex').value);
  const subject = document.getElementById('masterTtSubject').value.trim();
  const room = document.getElementById('masterTtRoom').value.trim();

  if (!subject) return;
  const formatted = `${subject} (${room})`;

  if (appState.timetable && appState.timetable[slotIdx]) {
    appState.timetable[slotIdx][day] = formatted;

    // Auto-sync subject to Attendance List!
    syncSubjectToAttendance(subject);

    saveState();
    renderMasterTimetable();
    closeMasterTimetableEditModal();
    showToast(`✅ Master Timetable updated for ${day}! Auto-registered in Attendance.`);

    if (window.fbDb && window.fbMethods) {
      try {
        const ttDoc = window.fbMethods.doc(window.fbDb, "system", "timetable");
        await window.fbMethods.setDoc(ttDoc, {
          slots: appState.timetable,
          updatedAt: window.fbMethods.serverTimestamp()
        }, { merge: true });

        const attDoc = window.fbMethods.doc(window.fbDb, "system", "attendance_subjects");
        await window.fbMethods.setDoc(attDoc, {
          subjects: appState.attendance.subjects,
          updatedAt: window.fbMethods.serverTimestamp()
        }, { merge: true });
      } catch(err) {}
    }
  }
}

function syncSubjectToAttendance(rawSubjectName) {
  if (!appState.attendance || !appState.attendance.subjects) return;
  const cleanName = rawSubjectName.replace(/\s*\(.*\)/g, '').trim();
  const exists = appState.attendance.subjects.some(s => s.name.toLowerCase() === cleanName.toLowerCase());

  if (!exists && cleanName.length > 1) {
    const newId = appState.attendance.subjects.length > 0 
      ? Math.max(...appState.attendance.subjects.map(s => s.id)) + 1 
      : 1;

    appState.attendance.subjects.push({
      id: newId,
      name: cleanName,
      attended: 10,
      total: 12,
      percent: 83
    });
    appState.attendance.totalSubjects = appState.attendance.subjects.length;
  }
}

// ----------------- 5. SPECIAL FACULTY DOCUMENTS VAULT -----------------
function handleFacultyFilePick(e) {
  const file = e.target.files[0];
  if (!file) return;

  selectedFacultyFile = file;
  const kb = Math.round(file.size / 1024);
  const sizeFormatted = kb > 1024 ? (kb / 1024).toFixed(1) + " MB" : kb + " KB";

  const titleInput = document.getElementById('facultyDocTitle');
  if (!titleInput.value) {
    titleInput.value = file.name;
  }

  document.getElementById('facultyFilePlaceholder').classList.add('hidden');
  document.getElementById('facultyFileSelectedBadge').classList.remove('hidden');
  document.getElementById('facultyFileName').innerText = "📄 " + file.name;
  document.getElementById('facultyFileSize').innerText = `${sizeFormatted} • Selected for Vault`;
}

function openFacultyDocUploadModal() {
  selectedFacultyFile = null;
  const fileInput = document.getElementById('facultyFileInput');
  if (fileInput) fileInput.value = '';
  document.getElementById('facultyFilePlaceholder').classList.remove('hidden');
  document.getElementById('facultyFileSelectedBadge').classList.add('hidden');
  document.getElementById('facultyDocTitle').value = '';
  document.getElementById('facultyDocModal').classList.remove('hidden');
}

function closeFacultyDocUploadModal() {
  document.getElementById('facultyDocModal').classList.add('hidden');
}

async function handleFacultyDocSave(e) {
  e.preventDefault();
  const title = document.getElementById('facultyDocTitle').value.trim();
  const category = document.getElementById('facultyDocCategory').value;
  const subject = document.getElementById('facultyDocSubject').value.trim();

  let size = "1.8 MB";
  let downloadUrl = null;

  if (selectedFacultyFile) {
    const kb = Math.round(selectedFacultyFile.size / 1024);
    size = kb > 1024 ? (kb / 1024).toFixed(1) + " MB" : kb + " KB";
    downloadUrl = URL.createObjectURL(selectedFacultyFile);
  }

  showToast("Saving document to Faculty Vault...");

  let docId = Date.now().toString();

  if (window.fbDb && window.fbMethods) {
    try {
      const docRef = await window.fbMethods.addDoc(window.fbMethods.collection(window.fbDb, "faculty_documents"), {
        title,
        category,
        subject,
        size,
        date: "Today",
        uploader: "Dr. Amit Sharma",
        createdAt: window.fbMethods.serverTimestamp()
      });
      docId = docRef.id;
    } catch(err) {}
  }

  appState.facultyDocuments.unshift({
    id: docId,
    title,
    category,
    subject,
    size,
    date: "Just now",
    downloadUrl
  });
  saveState();

  closeFacultyDocUploadModal();
  renderFacultyDocsGrid('all');
  showToast(`✅ '${title}' saved to Faculty Vault!`);
}

function renderFacultyDocsGrid(filter = 'all') {
  const container = document.getElementById('facultyDocumentsGrid');
  if (!container) return;

  const docs = appState.facultyDocuments || [];
  const filtered = filter === 'all' ? docs : docs.filter(d => d.category === filter);

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="col-span-full p-8 text-center text-xs text-slate-400 font-medium bg-white rounded-2xl border border-slate-200">
        No documents found in this category.
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(d => `
    <div class="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm hover:border-indigo-300 transition flex items-start justify-between">
      <div class="flex items-start gap-3 truncate">
        <span class="text-2xl">${getFacultyDocBadgeIcon(d.category)}</span>
        <div class="truncate">
          <h4 class="text-xs font-bold text-slate-800 hover:text-indigo-600 cursor-pointer truncate" onclick="downloadFacultyDoc('${d.title}', '${d.downloadUrl || ''}')">${d.title}</h4>
          <p class="text-[10px] text-slate-400 mt-0.5">${d.subject} • ${d.size} • ${d.date}</p>
          <span class="inline-block mt-1.5 px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider ${getCategoryBadgeStyle(d.category)}">
            ${getCategoryLabel(d.category)}
          </span>
        </div>
      </div>

      <div class="flex items-center gap-1 shrink-0 ml-2">
        <button onclick="downloadFacultyDoc('${d.title}', '${d.downloadUrl || ''}')" title="Preview" class="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg">👁️</button>
        <button onclick="deleteFacultyDoc('${d.id}')" title="Delete" class="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg">🗑️</button>
      </div>
    </div>
  `).join('');
}

function filterFacultyDocs(cat) {
  const tabs = document.querySelectorAll('#facultyDocTabs button');
  tabs.forEach(t => t.className = 'px-3.5 py-1.5 rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200');
  if (event && event.target) {
    event.target.className = 'px-3.5 py-1.5 rounded-xl bg-slate-900 text-white';
  }
  renderFacultyDocsGrid(cat);
}

function downloadFacultyDoc(title, url) {
  if (url && url !== 'null' && url !== 'undefined') {
    const a = document.createElement('a');
    a.href = url;
    a.download = title;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast(`Downloading: ${title}`);
  } else {
    showToast(`📄 Faculty document preview loaded: ${title}`);
  }
}

function deleteFacultyDoc(id) {
  appState.facultyDocuments = appState.facultyDocuments.filter(d => d.id != id);
  saveState();
  renderFacultyDocsGrid('all');
  showToast("Document deleted from Faculty Vault");
}

function getFacultyDocBadgeIcon(cat) {
  if (cat === 'qp') return '📝';
  if (cat === 'syllabus') return '📘';
  if (cat === 'rubric') return '📊';
  return '📢';
}

function getCategoryBadgeStyle(cat) {
  if (cat === 'qp') return 'bg-rose-100 text-rose-800';
  if (cat === 'syllabus') return 'bg-blue-100 text-blue-800';
  if (cat === 'rubric') return 'bg-emerald-100 text-emerald-800';
  return 'bg-purple-100 text-purple-800';
}

function getCategoryLabel(cat) {
  if (cat === 'qp') return 'Question Paper';
  if (cat === 'syllabus') return 'Syllabus Blueprint';
  if (cat === 'rubric') return 'Evaluation Rubric';
  return 'Official Circular';
}

// ----------------- NOTICE BROADCAST -----------------
function openNoticeModal() {
  document.getElementById('noticeModal').classList.remove('hidden');
}

function closeNoticeModal() {
  document.getElementById('noticeModal').classList.add('hidden');
}

async function submitNoticeBroadcast() {
  const textarea = document.getElementById('facultyNoticeTextarea');
  const txt = textarea.value.trim();
  if (!txt) return;

  const newNotice = {
    id: Date.now(),
    text: `📢 Faculty Broadcast: ${txt}`,
    unread: true,
    time: 'Just now'
  };

  appState.notifications.unshift(newNotice);
  saveState();
  textarea.value = '';
  closeNoticeModal();
  showToast("Notice broadcasted to all students!");

  if (window.fbDb && window.fbMethods) {
    try {
      await window.fbMethods.addDoc(window.fbMethods.collection(window.fbDb, "notices"), {
        text: newNotice.text,
        sender: "Dr. Amit Sharma",
        createdAt: window.fbMethods.serverTimestamp()
      });
    } catch(e) {}
  }
}
