// Global Navigation, Notifications, Header Sync & AI Copilot
function updateHeader() {
  const current = JSON.parse(localStorage.getItem('smart_campus_current_session') || 'null');
  const user = current || (typeof appState !== 'undefined' && appState.currentUser) || { name: 'Student', role: 'student' };
  
  const nameEl = document.getElementById('headerUserName');
  const roleEl = document.getElementById('headerUserRole');
  
  if (nameEl) nameEl.innerText = user.name || 'Student';
  if (roleEl) roleEl.innerText = user.role === 'teacher' ? 'Faculty / Teacher' : 'Student';
  
  renderNotifications();
}

function logoutSession() {
  localStorage.removeItem('smart_campus_current_session');
  if (typeof appState !== 'undefined') {
    appState.currentUser = null;
    if (typeof saveState === 'function') saveState();
  }
  window.location.href = 'login.html';
}

function toggleNotifications() {
  const pop = document.getElementById('notifPopover');
  if (pop) pop.classList.toggle('hidden');
}

function renderNotifications() {
  const container = document.getElementById('notifListContainer');
  const badge = document.getElementById('notifBadge');
  if (!container || !badge || typeof appState === 'undefined' || !appState.notifications) return;

  const unreadCount = appState.notifications.filter(n => n.unread).length;
  badge.style.display = unreadCount > 0 ? 'block' : 'none';

  container.innerHTML = appState.notifications.map(n => `
    <div class="p-2.5 rounded-xl text-xs ${n.unread ? 'bg-indigo-50/70 border border-indigo-100 font-semibold' : 'bg-slate-50 text-slate-600'}">
      <div>${n.text}</div>
      <div class="text-[10px] text-slate-400 mt-1">${n.time}</div>
    </div>
  `).join('');
}

function markAllNotifsRead() {
  if (typeof appState !== 'undefined' && appState.notifications) {
    appState.notifications.forEach(n => n.unread = false);
    if (typeof saveState === 'function') saveState();
    renderNotifications();
  }
}

// AI Copilot Drawer
function toggleAiDrawer() {
  const drawer = document.getElementById('aiDrawer');
  if (drawer) drawer.classList.toggle('translate-x-full');
}

function sendQuickAiQuery(query) {
  const input = document.getElementById('aiInput');
  if (input) {
    input.value = query;
    submitAiMessage();
  }
}

function submitAiMessage() {
  const input = document.getElementById('aiInput');
  if (!input) return;
  const text = input.value.trim();
  if (!text) return;

  const box = document.getElementById('aiChatMessages');
  if (box) {
    box.innerHTML += `
      <div class="p-3 rounded-2xl bg-indigo-600 text-white ml-8 text-right font-medium">
        ${text}
      </div>
    `;
    input.value = '';

    setTimeout(() => {
      let reply = "Me campus system madhe check kela. Tumcha schedule aani data normal ahe!";
      if (text.toLowerCase().includes('schedule')) {
        reply = "Aajche lectures: 09:00 AM Maths III, 11:00 AM Operating Systems Lab, ani 02:00 PM HCI Seminar.";
      } else if (text.toLowerCase().includes('attendance')) {
        reply = "Tumche overall attendance safe range madhe ahe!";
      } else if (text.toLowerCase().includes('assignment') || text.toLowerCase().includes('deadline')) {
        reply = "Upcoming: Database Project (Due Tomorrow - Urgent), AI Lab Submission (in 3 days).";
      }

      box.innerHTML += `
        <div class="p-3 rounded-2xl bg-slate-100 text-slate-800 leading-relaxed font-normal">
          ${reply}
        </div>
      `;
      box.scrollTop = box.scrollHeight;
    }, 400);
  }
}

document.addEventListener('DOMContentLoaded', updateHeader);
