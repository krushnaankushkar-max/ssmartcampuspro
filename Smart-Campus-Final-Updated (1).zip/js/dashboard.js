// Dynamic Home Bento Dashboard with Real-Time Class & Today's Schedule Engine

document.addEventListener('DOMContentLoaded', () => {
  // Sync latest user session and load state
  if (typeof loadAppState === 'function') {
    appState = loadAppState();
  }
  initStudentLiveSync();
  renderDynamicTodaySchedule();
  renderStudentBento();
  setInterval(renderDynamicTodaySchedule, 60000);
});

function initStudentLiveSync() {
  if (window.fbDb && window.fbMethods) {
    // Real-time Timetable sync
    const ttDoc = window.fbMethods.doc(window.fbDb, "system", "timetable");
    window.fbMethods.onSnapshot(ttDoc, (snap) => {
      if (snap.exists() && snap.data().slots) {
        appState.timetable = snap.data().slots;
        saveState();
        renderDynamicTodaySchedule();
      }
    });

    
  }
}

function getDayName() {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const now = new Date();
  return days[now.getDay()];
}

function parseTimeToMinutes(timeStr) {
  const clean = timeStr.trim().toUpperCase();
  const parts = clean.split(' ');
  const timePart = parts[0];
  const modifier = parts[1];
  let [hours, minutes] = timePart.split(':').map(Number);
  if (modifier === 'PM' && hours < 12) hours += 12;
  if (modifier === 'AM' && hours === 12) hours = 0;
  return hours * 60 + minutes;
}

function renderDynamicTodaySchedule() {
  const currentDay = getDayName();
  const activeDay = (currentDay === 'Sunday' || currentDay === 'Saturday') ? 'Monday' : currentDay;
  
  const scheduleContainer = document.getElementById('todayScheduleTimeline');
  const scheduleHeader = document.getElementById('todayScheduleDayName');
  if (scheduleHeader) {
    scheduleHeader.innerText = `Schedule (${currentDay === 'Sunday' || currentDay === 'Saturday' ? activeDay + ' Preview' : currentDay})`;
  }

  const timetable = appState.timetable || [];
  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();

  let liveLectureFound = null;
  let timelineHtml = '';

  timetable.forEach((slot, idx) => {
    const lectureDesc = slot[activeDay] || 'Self Study / Library';
    const [startStr, endStr] = slot.time.split(' - ');
    const startMins = parseTimeToMinutes(startStr);
    const endMins = parseTimeToMinutes(endStr);

    let status = 'Later';
    let dotColor = 'bg-slate-400';
    let cardBg = 'bg-slate-50 border-slate-200/70';
    let badgeClass = 'bg-slate-200 text-slate-700';

    if (currentMinutes >= startMins && currentMinutes <= endMins && currentDay === activeDay) {
      status = 'Live Now';
      dotColor = 'bg-rose-500 animate-ping';
      cardBg = 'bg-rose-50/80 border-rose-200 ring-2 ring-rose-500/20';
      badgeClass = 'bg-rose-100 text-rose-700 font-extrabold';
      liveLectureFound = { desc: lectureDesc, time: slot.time };
    } else if (currentMinutes < startMins) {
      status = 'Upcoming';
      dotColor = 'bg-emerald-500 ring-2 ring-emerald-100';
      cardBg = 'bg-emerald-50/80 border-emerald-100';
      badgeClass = 'bg-emerald-100 text-emerald-800';
    } else {
      status = 'Completed';
      dotColor = 'bg-blue-400';
      cardBg = 'bg-blue-50/50 border-blue-100 text-slate-500';
      badgeClass = 'bg-blue-100 text-blue-700';
    }

    if ((currentDay === 'Sunday' || currentDay === 'Saturday') && idx === 0) {
      status = 'Next Class';
      badgeClass = 'bg-blue-100 text-blue-800 font-bold';
      dotColor = 'bg-blue-600';
      cardBg = 'bg-blue-50/70 border-blue-200';
      liveLectureFound = { desc: lectureDesc, time: slot.time };
    }

    timelineHtml += `
      <div class="relative">
        <span class="absolute -left-[27px] top-1.5 w-3 h-3 rounded-full ${dotColor} border-2 border-white"></span>
        <div class="text-[11px] font-bold text-slate-400">${slot.time}</div>
        <div class="mt-1 p-3 rounded-2xl ${cardBg} border transition hover:shadow-sm">
          <div class="flex items-center justify-between mb-0.5">
            <span class="text-xs font-bold text-slate-900">${lectureDesc}</span>
            <span class="text-[10px] font-bold px-2 py-0.5 rounded-full ${badgeClass}">${status}</span>
          </div>
          <p class="text-[11px] text-slate-500">Scheduled on ${activeDay}</p>
        </div>
      </div>
    `;
  });

  if (scheduleContainer) {
    scheduleContainer.innerHTML = timelineHtml;
  }

  // Update Live Class Bento Card
  const liveTitle = document.getElementById('liveClassTitle');
  const liveTeacher = document.getElementById('liveClassTeacher');
  const liveRoom = document.getElementById('liveClassRoom');
  const liveBadge = document.getElementById('liveClassBadge');

  if (liveLectureFound) {
    if (liveTitle) liveTitle.innerText = liveLectureFound.desc;
    if (liveTeacher) liveTeacher.innerText = `Active Session • ${liveLectureFound.time}`;
    if (liveRoom) liveRoom.innerText = `Campus Room / Lab Allocated`;
  } else {
    if (liveTitle) liveTitle.innerText = "No Live Lecture Active";
    if (liveTeacher) liveTeacher.innerText = "Next session starts tomorrow at 09:00 AM";
    if (liveRoom) liveRoom.innerText = "Campus Labs Open for Self Study";
    if (liveBadge) liveBadge.innerHTML = `<span class="w-2 h-2 rounded-full bg-slate-400"></span> Inactive`;
  }
}

function renderStudentBento() {
  const att = appState.attendance || { overallPercentage: 85, safeSubjects: 5, totalSubjects: 6, attended: 34, missed: 6 };

  const attPercentEl = document.getElementById('bentoAttPercent');
  if (attPercentEl) attPercentEl.innerText = `${att.overallPercentage}%`;
  
  const safeEl = document.getElementById('bentoSafeCount');
  if (safeEl) safeEl.innerText = `${att.safeSubjects}/${att.totalSubjects}`;
  
  const attCountEl = document.getElementById('bentoAttendedCount');
  if (attCountEl) attCountEl.innerText = att.attended;
  
  const missCountEl = document.getElementById('bentoMissedCount');
  if (missCountEl) missCountEl.innerText = att.missed;

  const offset = 251.2 - (251.2 * att.overallPercentage) / 100;
  const circle = document.getElementById('bentoCircleProgress');
  if (circle) circle.style.strokeDashoffset = offset;

  // Personal Tasks preview for this specific student
  const taskBox = document.getElementById('bentoTasksList');
  const userSubs = appState.submissions || {};

  if (taskBox) {
    taskBox.innerHTML = (appState.assignments || []).slice(0, 3).map(a => {
      const isSub = !!userSubs[a.id];
      const st = isSub ? 'Completed' : (a.status || 'Pending');
      return `
        <div class="flex items-center justify-between text-xs py-1 border-b border-slate-50 last:border-0">
          <div>
            <div class="font-bold text-slate-800">${a.title}</div>
            <div class="text-[10px] text-slate-400">${isSub ? 'Submitted Solution' : a.due}</div>
          </div>
          <span class="px-2 py-0.5 rounded-full text-[10px] font-extrabold ${getStatusStyle(st)}">${st}</span>
        </div>
      `;
    }).join('');
  }

  // Personal Documents preview
  const docBox = document.getElementById('bentoDocsList');
  if (docBox) {
    const userDocs = appState.documents || [];
    docBox.innerHTML = userDocs.slice(0, 3).map(d => `
      <div class="flex items-center gap-2 p-1.5 rounded-xl hover:bg-slate-50 transition cursor-pointer" onclick="showToast('Opening: ${d.title}')">
        <span class="text-sm">${getDocIcon(d.type)}</span>
        <div class="truncate text-xs">
          <div class="font-semibold text-slate-800 truncate">${d.title}</div>
          <div class="text-[10px] text-slate-400">${d.size}</div>
        </div>
      </div>
    `).join('');
  }
}

function getStatusStyle(st) {
  if (st === 'Urgent') return 'bg-rose-100 text-rose-700';
  if (st === 'Pending') return 'bg-amber-100 text-amber-700';
  return 'bg-emerald-100 text-emerald-700';
}

function getDocIcon(type) {
  if (type === 'pdf') return '📕';
  if (type === 'doc') return '📘';
  if (type === 'sheet') return '📗';
  if (type === 'slide') return '📙';
  return '📁';
}