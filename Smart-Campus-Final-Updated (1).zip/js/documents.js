// Documents Vault Manager with User-Isolated Cloud Storage Sync
let selectedFileObject = null;

document.addEventListener('DOMContentLoaded', () => {
  renderDocsGrid();
  initDocsCloudSync();
});

function initDocsCloudSync() {
  if (window.fbDb && window.fbMethods) {
    const userEmail = appState.currentUser ? appState.currentUser.email : '';
    
    window.fbMethods.onSnapshot(window.fbMethods.collection(window.fbDb, "documents"), (snap) => {
      snap.docChanges().forEach((change) => {
        const docData = change.doc.data();
        if (change.type === "added") {
          // Strict Privacy Filter: show only official campus docs OR docs uploaded by this user!
          const isOwner = docData.uploaderEmail === userEmail;
          const isOfficial = !docData.uploaderEmail || docData.isPublic === true || docData.uploaderRole === 'teacher';

          if (isOwner || isOfficial) {
            const exists = appState.documents.some(d => d.id === change.doc.id || d.title === docData.title);
            if (!exists) {
              appState.documents.unshift({
                id: change.doc.id,
                title: docData.title,
                type: docData.type,
                subject: docData.subject,
                size: docData.size || '1.5 MB',
                date: docData.date || 'Just now',
                downloadUrl: docData.downloadUrl || null,
                isPrivate: isOwner
              });
              saveState();
              renderDocsGrid();
            }
          }
        }
      });
    });
  }
}

function handleFileSelection(event) {
  const file = event.target.files[0];
  if (!file) return;

  selectedFileObject = file;
  const fileName = file.name;
  const fileSizeKb = Math.round(file.size / 1024);
  const sizeFormatted = fileSizeKb > 1024 ? (fileSizeKb / 1024).toFixed(1) + " MB" : fileSizeKb + " KB";

  const titleInput = document.getElementById('newDocTitle');
  if (!titleInput.value) {
    titleInput.value = fileName;
  }

  const ext = fileName.split('.').pop().toLowerCase();
  const typeSelect = document.getElementById('newDocType');
  if (['pdf'].includes(ext)) typeSelect.value = 'pdf';
  else if (['doc', 'docx'].includes(ext)) typeSelect.value = 'doc';
  else if (['xls', 'xlsx', 'csv'].includes(ext)) typeSelect.value = 'sheet';
  else if (['ppt', 'pptx'].includes(ext)) typeSelect.value = 'slide';
  else if (['zip', 'rar', 'js', 'py', 'cpp', 'html'].includes(ext)) typeSelect.value = 'code';

  document.getElementById('fileUploadPlaceholder').classList.add('hidden');
  const infoBox = document.getElementById('fileSelectedInfo');
  infoBox.classList.remove('hidden');
  document.getElementById('selectedFileName').innerText = "📄 " + fileName;
  document.getElementById('selectedFileSize').innerText = `${sizeFormatted} • Ready to upload`;
}

function renderDocsGrid(filter = 'all') {
  const container = document.getElementById('documentsListGrid');
  if (!container) return;

  const filtered = filter === 'all' ? appState.documents : appState.documents.filter(d => d.type === filter);

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="col-span-full p-8 text-center text-xs text-slate-400 font-medium bg-white rounded-2xl border border-slate-200">
        No personal documents uploaded yet. Click "+ Upload Document" to store your notes.
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(d => `
    <div class="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow transition flex items-start justify-between">
      <div class="flex items-start gap-3 truncate">
        <span class="text-2xl">${getDocIcon(d.type)}</span>
        <div class="truncate">
          <h4 class="text-xs font-bold text-slate-800 hover:text-indigo-600 cursor-pointer truncate" onclick="handleDocDownload('${d.title}', '${d.downloadUrl || ''}')">${d.title}</h4>
          <p class="text-[10px] text-slate-400 mt-0.5">${d.subject} • ${d.size} • ${d.date}</p>
        </div>
      </div>
      <div class="flex items-center gap-1.5 shrink-0 ml-2">
        <button onclick="handleDocDownload('${d.title}', '${d.downloadUrl || ''}')" title="Preview / Download" class="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg">👁️</button>
        <button onclick="deleteDocItem('${d.id}', '${d.title}')" title="Delete" class="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg">🗑️</button>
      </div>
    </div>
  `).join('');
}

function filterDocs(cat) {
  const tabs = document.querySelectorAll('#docCategoryTabs button');
  tabs.forEach(t => {
    t.className = 'px-3.5 py-1.5 rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200';
  });
  if (event && event.target) {
    event.target.className = 'px-3.5 py-1.5 rounded-xl bg-slate-900 text-white';
  }
  renderDocsGrid(cat);
}

function openUploadDocDialog() {
  selectedFileObject = null;
  const input = document.getElementById('actualFileInput');
  if (input) input.value = '';
  const ph = document.getElementById('fileUploadPlaceholder');
  if (ph) ph.classList.remove('hidden');
  const info = document.getElementById('fileSelectedInfo');
  if (info) info.classList.add('hidden');
  document.getElementById('uploadDocModal').classList.remove('hidden');
}

function closeUploadDocDialog() {
  document.getElementById('uploadDocModal').classList.add('hidden');
}

async function handleDocUpload(e) {
  e.preventDefault();
  const title = document.getElementById('newDocTitle').value.trim();
  const type = document.getElementById('newDocType').value;
  const subject = document.getElementById('newDocSubject').value.trim();

  let fileSize = "1.8 MB";
  let downloadUrl = null;

  if (selectedFileObject) {
    const kb = Math.round(selectedFileObject.size / 1024);
    fileSize = kb > 1024 ? (kb / 1024).toFixed(1) + " MB" : kb + " KB";
    downloadUrl = URL.createObjectURL(selectedFileObject);
  }

  showToast("Saving file to your Personal Vault...");

  let docId = 'doc_' + Date.now().toString();

  const user = appState.currentUser;
  const userEmail = user ? user.email : '';
  const userName = appState.profile ? appState.profile.name : (user ? user.name : 'Student');

  // Firebase Storage Real Upload (If connected)
  if (window.fbStorage && window.fbMethods && selectedFileObject) {
    try {
      const storageRef = window.fbMethods.ref(window.fbStorage, `documents/${Date.now()}_${selectedFileObject.name}`);
      const uploadSnapshot = await window.fbMethods.uploadBytes(storageRef, selectedFileObject);
      const cloudUrl = await window.fbMethods.getDownloadURL(uploadSnapshot.ref);
      if (cloudUrl) downloadUrl = cloudUrl;
    } catch(storageErr) {
      console.warn("Storage upload notice (falling back to local stream):", storageErr);
    }
  }

  if (window.fbDb && window.fbMethods) {
    try {
      const docRef = await window.fbMethods.addDoc(window.fbMethods.collection(window.fbDb, "documents"), {
        title,
        type,
        subject,
        size: fileSize,
        date: 'Today',
        uploader: userName,
        uploaderEmail: userEmail,
        uploaderRole: user ? user.role : 'student',
        isPublic: false,
        downloadUrl: downloadUrl,
        createdAt: window.fbMethods.serverTimestamp()
      });
      docId = docRef.id;
    } catch(err) {
      console.warn("Firestore document upload notice:", err);
    }
  }

  // Save strictly inside THIS user's isolated documents array
  appState.documents.unshift({
    id: docId,
    title,
    type,
    subject,
    size: fileSize,
    date: 'Just now',
    downloadUrl: downloadUrl,
    isPrivate: true
  });
  saveState();

  closeUploadDocDialog();
  renderDocsGrid();
  showToast(`✅ '${title}' saved to your personal vault!`);
}

async function deleteDocItem(id, title) {
  appState.documents = appState.documents.filter(d => d.id !== id && d.title !== title);
  saveState();
  renderDocsGrid();
  showToast('Document deleted');

  if (window.fbDb && window.fbMethods && isNaN(id) && !id.startsWith('doc_')) {
    try {
      await window.fbMethods.deleteDoc(window.fbMethods.doc(window.fbDb, "documents", id));
    } catch(e) {}
  }
}

function handleDocDownload(title, url) {
  if (url && url !== 'null' && url !== 'undefined') {
    const a = document.createElement('a');
    a.href = url;
    a.download = title;
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast(`Downloading: ${title}`);
  } else {
    showToast(`📄 Document preview loaded: ${title}`);
  }
}

function getDocIcon(type) {
  if (type === 'pdf') return '📕';
  if (type === 'doc') return '📘';
  if (type === 'sheet') return '📗';
  if (type === 'slide') return '📙';
  return '📁';
}
